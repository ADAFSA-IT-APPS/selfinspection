export default {
    'In_Progress':'In Progress',
    'Establishment_Name':'Establishment Name',
    'English':'English'
};