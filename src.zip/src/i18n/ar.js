export default {
    "In_Progress": "في تَقَدم",
    'Establishment_Name':'اسم المؤسسة',
    'English':'عربي'
};