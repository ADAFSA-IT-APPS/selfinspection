export const Data = [
    {
        id: 0,
        question: 'What ',
        answer: 'I A.',
        DataInner: [
            {
                question: 'Brand Name',
                answer: 'I A.'
            },
            {
                question: 'Company Name',
                answer: 'A labracadabrador.bhghvguyvhvjhvnbhvjhvhjvjvjhvjhvjhvjh'
            },
        ],

    },
    {
        id: 1,
        question: 'Whats do you call a dog magician?',
        answer: 'A labracadabrador.',
        DataInner: [
            {
                question: 'Brand Name',
                answer: 'I A.'
            },
            {
                question: 'Company Name',
                answer: 'A labracadabrador.bhghvguyvhvjhvnbhvjhvhjvjvjhvjhvjhvjh',
                //image:'SI.jpeg'
                image: require('../assets/img/SI.jpeg')

            },
        ],
    },
    {
        id: 2,
        question: 'What do you call a funny mountain?',
        answer: 'Hill-arious.',
        DataInner: [
            {
                question: 'Brand Name',
                answer: 'I A.'
            },
            {
                question: 'Company Name',
                answer: 'A labracadabrador.bhghvguyvhvjhvnbhvjhvhjvjvjhvjhvjhvjh'
            },
        ],
    },
    {
        id: 3,

        question: 'What did the astronaut say when he crashed into the moon?',
        answer: 'I Apollo-gize.',
        DataInner: [
            {
                question: 'Brand Name',
                answer: 'I A.'
            },
            {
                question: 'Company Name',
                answer: 'A labracadabrador.bhghvguyvhvjhvnbhvjhvhjvjvjhvjhvjhvjh'
            },
        ],
    },
    {
        id: 4,

        question: 'What qq',
        answer: 'I A.',
        DataInner: [
            {
                question: 'Brand Name',
                answer: 'I A.'
            },
            {
                question: 'Company Name',
                answer: 'A labracadabrador.bhghvguyvhvjhvnbhvjhvhjvjvjhvjhvjhvjh'
            },
        ],
    },
    {
        id: 5,
        question: 'What qdo you call a dog magician?',
        answer: 'A labracadabrador.',
        DataInner: [
            {
                question: 'Brand Name',
                answer: 'I A.'
            },
            {
                question: 'Company Name',
                answer: 'A labracadabrador.bhghvguyvhvjhvnbhvjhvhjvjvjhvjhvjhvjh'
            },
        ],
    },
    {
        id: 6,
        question: 'Whatq do you call a funny mountain?',
        answer: 'Hill-arious.',
        DataInner: [
            {
                question: 'Brand Name',
                answer: 'I A.'
            },
            {
                question: 'Company Name',
                answer: 'A labracadabrador.bhghvguyvhvjhvnbhvjhvhjvjvjhvjhvjhvjh'
            },
        ],
    },
];
export const dataAssesment = [
    {
        PropertyChanged: null,
        descriptionField: "Documentation",
        listOfSalesAssessmentAttributeValueField: [
            {
                PropertyChanged: null,
                descriptionField: "",
                orderField: "1",
                scoreField: "1",
                valueField: "Yes"
            },
            {
                PropertyChanged: null,
                descriptionField: "",
                orderField: "2",
                scoreField: "1",
                valueField: "No"
            },
            {
                PropertyChanged: null,
                descriptionField: "",
                orderField: "3",
                scoreField: "1",
                valueField: "N/A"
            },
            {
                PropertyChanged: null,
                descriptionField: "",
                orderField: "4",
                scoreField: "1",
                valueField: "Partially"
            }
        ],
        nameField: "ADFCA EFST Program",
        orderField: "1"
    },
    {
        PropertyChanged: null,
        descriptionField: "Documentation",
        listOfSalesAssessmentAttributeValueField: [
            {
                PropertyChanged: null,
                descriptionField: "",
                orderField: "1",
                scoreField: "1",
                valueField: "Yes"
            },
            {
                PropertyChanged: null,
                descriptionField: "",
                orderField: "2",
                scoreField: "1",
                valueField: "No"
            },
            {
                PropertyChanged: null,
                descriptionField: "",
                orderField: "3",
                scoreField: "1",
                valueField: "N/A"
            },
            {
                PropertyChanged: null,
                descriptionField: "",
                orderField: "4",
                scoreField: "1",
                valueField: "Partially"
            }
        ],
        nameField: "ADFCA approvals/certificates and required licensing requirements",
        orderField: "2"
    }

];
/*    {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Building Maintenance",
       "orderField": "3"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Building cleanness",
       "orderField": "4"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food Handling Areas/Operations",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Chemicals usage & storage",
       "orderField": "5"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food Handling Areas/Operations",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Cooking tep./ Past. Temp./ heat treatment",
       "orderField": "6"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Display of unpackaged & ready to eat food",
       "orderField": "7"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Doors surfaces & conditions",
       "orderField": "8"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Drainage facilities",
       "orderField": "9"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Equipment/ Facilities",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Equipment design and materials",
       "orderField": "10"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Equipment/ Facilities",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Equipment kept clean and disinfectant (where applicable)",
       "orderField": "11"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Equipment/ Facilities",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Equipment maintenance and calibration",
       "orderField": "12"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Equipment/ Facilities",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Equipment/ facilities for waste disposal",
       "orderField": "13"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Equipment/ Facilities",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Equipment/tools/ facilities for Cleaning and disinfectant",
       "orderField": "14"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Food Protected from Contamination",
       "orderField": "15"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Documentation",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Food Safety Management system (FSMS)",
       "orderField": "16"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Food Separation",
       "orderField": "17"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Food Shelf life (No expired food)",
       "orderField": "18"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Food Storage Condition and temperature",
       "orderField": "19"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food Handling Areas/Operations",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Food Transportation vehicle (where applicable)",
       "orderField": "20"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food Handling Areas/Operations",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Food Washing facilities",
       "orderField": "21"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Halal & Non- Halal separation (where applicable)",
       "orderField": "22"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Hand wash Basin(s) & facilities",
       "orderField": "23"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food Handlers (Health & Personal Hygiene)",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Hand washing",
       "orderField": "24"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Light protection and intensity",
       "orderField": "25"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Packaging & Wrapping Materials",
       "orderField": "26"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food Handlers (Health & Personal Hygiene)",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Personnel behaviors",
       "orderField": "27"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food Handlers (Health & Personal Hygiene)",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Personnel health status, uniform & Protective clothing",
       "orderField": "28"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food Handling Areas/Operations",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Pest Control",
       "orderField": "29"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Documentation",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Pest Control Program Records",
       "orderField": "30"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Raw materials, ingredients and food source",
       "orderField": "31"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Staff toilets and changing facilities (where applicable)",
       "orderField": "32"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Documentation",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Temp, cleaning, maintenance & calibration records.",
       "orderField": "33"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food Handling Areas/Operations",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Thawing Procedure (where applicable)",
       "orderField": "34"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "The ceiling surfaces materials",
       "orderField": "35"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "The floor Surfaces materials",
       "orderField": "36"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Documentation",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "The food handler health status records",
       "orderField": "37"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "The walls & partition surfaces Materials",
       "orderField": "38"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "The working space and process work flow",
       "orderField": "39"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Documentation",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Traceability & Recall system",
       "orderField": "40"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Ventilation",
       "orderField": "41"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Food Handling Areas/Operations",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Water and/or ice supply",
       "orderField": "42"
   },
   {
       "PropertyChanged": null,
       "descriptionField": "Design, building & Construction",
       "listOfSalesAssessmentAttributeValueField": [
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "1",
               "scoreField": "1",
               "valueField": "Yes"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "2",
               "scoreField": "1",
               "valueField": "No"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "3",
               "scoreField": "1",
               "valueField": "N/A"
           },
           {
               "PropertyChanged": null,
               "descriptionField": "",
               "orderField": "4",
               "scoreField": "1",
               "valueField": "Partially"
           }
       ],
       "nameField": "Windows & other opining",
       "orderField": "43"
   } */
export const DataRoutine = [
    {
        question: 'Salamat Zadna',
        DataInner: [
            {
                question: 'Salamat Zadna is a practical Food Safety Managament System (FSMS) developed for small,independent catering businesses in Abu Dhabi. it has been produced by the Abu Dhabi Agriculture and Food Safety Authority (ADAFSA) following extensive international benchmarching and in -depth local research. Whilist the system represents the minimum requirements of ADAFSA, Food business will be encouraged to achive higher standards through a long-term to achieve higher standards through a long-term process of continual improvement.',
                DataInnerLayer: [
                ],
            },
        ],
    },
    {
        question: 'Cross Contamination',
        DataInner: [
            {
                question: 'Hand Washing',
                DataInnerLayer: [

                    require('../assets/img/Manuals/HW1.png'),

                    require('../assets/img/Manuals/HW2.png'),

                ],
            },
            {
                question: 'Protective Clothing',
                DataInnerLayer: [
                    require('../assets/img/Manuals/PC.png'),

                    require('../assets/img/Manuals/PC2.png'),
                ],
            },
            {
                question: 'Protective Hygiene',
                DataInnerLayer: [
                    require('../assets/img/Manuals/PH.png'),
                ],
            },
            {
                question: 'Handling Ready-To-Eat Food',
                DataInnerLayer: [
                    require('../assets/img/Manuals/HRTEF.png'),

                    require('../assets/img/Manuals/HRTEF2.png'),
                ],
            },
            {
                question: 'When To Wash Hands',
                DataInnerLayer: [
                    require('../assets/img/Manuals/WTWH.png'),

                    require('../assets/img/Manuals/WTWH2.png'),
                ],
            },
        ],
    },
    {
        question: 'Cooking',
        DataInner: [
            {
                question: 'Hand Washing',
                DataInnerLayer: [

                    require('../assets/img/Manuals/HW1.png'),

                    require('../assets/img/Manuals/HW2.png'),

                ],
            },
            {
                question: 'Protective Clothing',
                DataInnerLayer: [
                    require('../assets/img/Manuals/PC.png'),

                    require('../assets/img/Manuals/PC2.png'),
                ],
            },
            {
                question: 'Protective Hygiene',
                DataInnerLayer: [
                    require('../assets/img/Manuals/PH.png'),
                ],
            },
            {
                question: 'Handling Ready-To-Eat Food',
                DataInnerLayer: [
                    require('../assets/img/Manuals/HRTEF.png'),

                    require('../assets/img/Manuals/HRTEF2.png'),
                ],
            },
            {
                question: 'When To Wash Hands',
                DataInnerLayer: [
                    require('../assets/img/Manuals/WTWH.png'),

                    require('../assets/img/Manuals/WTWH2.png'),
                ],
            },
        ],
    },
    {
        question: 'Cleaning',
        DataInner: [
            {
                question: 'Hand Washing',
                DataInnerLayer: [

                    require('../assets/img/Manuals/HW1.png'),

                    require('../assets/img/Manuals/HW2.png'),

                ],
            },
            {
                question: 'Protective Clothing',
                DataInnerLayer: [
                    require('../assets/img/Manuals/PC.png'),

                    require('../assets/img/Manuals/PC2.png'),
                ],
            },
            {
                question: 'Protective Hygiene',
                DataInnerLayer: [
                    require('../assets/img/Manuals/PH.png'),
                ],
            },
            {
                question: 'Handling Ready-To-Eat Food',
                DataInnerLayer: [
                    require('../assets/img/Manuals/HRTEF.png'),

                    require('../assets/img/Manuals/HRTEF2.png'),
                ],
            },
            {
                question: 'When To Wash Hands',
                DataInnerLayer: [
                    require('../assets/img/Manuals/WTWH.png'),

                    require('../assets/img/Manuals/WTWH2.png'),
                ],
            },
        ],
    },
    {
        question: 'Chilling',
        DataInner: [
            {
                question: 'Hand Washing',
                DataInnerLayer: [

                    require('../assets/img/Manuals/HW1.png'),

                    require('../assets/img/Manuals/HW2.png'),

                ],
            },
            {
                question: 'Protective Clothing',
                DataInnerLayer: [
                    require('../assets/img/Manuals/PC.png'),

                    require('../assets/img/Manuals/PC2.png'),
                ],
            },
            {
                question: 'Protective Hygiene',
                DataInnerLayer: [
                    require('../assets/img/Manuals/PH.png'),
                ],
            },
            {
                question: 'Handling Ready-To-Eat Food',
                DataInnerLayer: [
                    require('../assets/img/Manuals/HRTEF.png'),

                    require('../assets/img/Manuals/HRTEF2.png'),
                ],
            },
            {
                question: 'When To Wash Hands',
                DataInnerLayer: [
                    require('../assets/img/Manuals/WTWH.png'),

                    require('../assets/img/Manuals/WTWH2.png'),
                ],
            },
        ],
    },
];