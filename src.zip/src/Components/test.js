initialLoginState = {
    isLoading: true,
    userName: null,
    userToken: null
}

loginReducer = (prevState, action) => {
    switch (action.type) {
        case 'RETRIEVE_TOKEN':
            return {
                ...prevState,
                userToken: action.token,
                isLoading: false,

            };
        case 'LOGIN':
            return {
                ...prevState,
                userName: action.id,
                userToken: action.token,
                isLoading: false,
            };
        case 'LOGOUT':
            return {
                ...prevState,
                userName: null,
                userToken: null,
                isLoading: false,
            };
    }
};

// const [loginState, dispatch] = useReducer(loginReducer, initialLoginState);

const authContext = useMemo(() => ({
    signIn: async (userName, password) => {
        // setUserToken('asdf');
        // setIsLoading(false);
        let userToken;
        userToken = null;
        if (userName == 'user' && password == 'pass') {

            try {
                userToken = 'asdf';
                await AsyncStorage.setItem('userToken', userToken)
            } catch (e) {
                // saving error
            }
        }
        dispatch({ type: 'LOGIN', id: userName, token: userToken });
    },
    signOut: async () => {
        // setUserToken(null);
        // setIsLoading(false);
        try {
            await AsyncStorage.removeItem('userToken')
        } catch (e) {
            // saving error
        }
        dispatch({ type: 'LOGOUT' });

    }
}), []);

useEffect(() => {
    console.log('state', loginState)
    /*         setTimeout(async () => {
            // setIsLoading(false)
            let userToken;
            userToken = null;
            try {
                userToken = await AsyncStorage.getItem('userToken')
            } catch (e) {
                // saving error
            }
            dispatch({ type: 'RETRIEVE_TOKEN', token: userToken });
    
        }, 1000); */
    dispatch(retrieveToken())
}, []);



/* android:windowSoftInputMode="stateAlwaysHidden|adjustPan" */

//import liraries
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image, Modal, Pressable } from 'react-native';
import { Data, DataRoutine } from './DummyData';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import Accordion from 'react-native-collapsible/Accordion';
import * as Animatable from 'react-native-animatable';
import ModalComp from './ModalComp';
import Collapsible from 'react-native-collapsible';


// create a component
const Accordian = ({ data }) => {
    const [activeSections, setActiveSections] = useState([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [calculatedHieght, setCalculatedHieght] = useState();

    useEffect(() => {
        console.log('data', data)
    }, [])

    const onLayout = (event) => {
        const { x, y, height, width } = event.nativeEvent.layout;
        console.log("~~~~~~ height = ", height);
        setCalculatedHieght(height + 20)
    }

    _renderSectionTitle = (section) => {
        return (
            <View style={styles.content}>
                {/* <Text>{section.content}</Text> */}
            </View>
        );
    };

    _renderHeader = (section, i, isActive, sections) => {
        return (
            <View
                duration={800}
                transition="backgroundColor"
                style={[styles.headerCont]}>
                <View style={styles.header} key={i}>
                    <Text style={styles.headerText}>{section.question}</Text>
                    {isActive ? <MaterialIcons name='keyboard-arrow-up' color='#fff' size={32} /> : <MaterialIcons name='keyboard-arrow-down' color='#fff' size={32} />}
                    {/* <MaterialIcons name='keyboard-arrow-down' color='#fff' size={32} /> */}
                </View>
            </View>
        );
    };

    _renderContent = (section, i, isActive, sections) => {
        return (
            <View
                duration={800}
                style={[styles.content, { margin: 20 }]} key={i}>
                <View
                    duration={800}
                    easing="ease-out"
                    style={{ borderColor: '#5c6672', borderWidth: 2, borderRadius: 5, }}
                >
                    {section.DataInner.map((item, index) => {
                        return (
                            <View onLayout={onLayout} key={index} style={{ flex: 1, flexDirection: 'column', padding: 8 }}>
                                <View style={(index === item.length - 1) ? styles.tableNoBorder : styles.table}>
                                    <Text style={styles.widthff}>
                                        {item.question}
                                    </Text>
                                    <Text style={{ alignSelf: 'center', width: '10%', textAlign: 'center' }}>:</Text>
                                    <Text style={styles.widthff}>
                                        {item.answer}
                                    </Text>
                                </View>
                                <View style={styles.table}>
                                    <Text style={styles.widthff}>Production Image</Text>
                                    <Text style={styles.tableColon}>:</Text>
                                    {item.image ? <Pressable onPress={() => setModalVisible(true)} style={{ width: '40%', marginTop: '2%' }}>
                                        <Image style={[styles.pic, { alignSelf: 'center', }]} source={item.image} />
                                        <ModalComp modalVisible={modalVisible} setModalVisible={setModalVisible} image={item.image} />
                                    </Pressable> : <Text></Text>}
                                </View>
                            </View>
                        )
                    })}
                </View>
            </View>
        );
    };

    _updateSections = (activeSections) => {
        setActiveSections(activeSections);
    };

    return (
        <View style={styles.container}>
                        <Accordion
                sections={Data}
                activeSections={activeSections}
                renderSectionTitle={_renderSectionTitle}
                renderHeader={_renderHeader}
                renderContent={_renderContent}
                onChange={_updateSections}
            />

        </View>
    );
};

// define your styles
const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: '10%'
        /*  height:'60%' */
    },
    content: {

    },
    widthff: { width: '45%' },
    headerCont: {
        backgroundColor: '#5c6672',
        borderBottomColor: '#fff',
        borderWidth: 1,
        borderTopColor: '#738591'
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: '4%',
        paddingVertical: '1%'
    },
    headerText: {
        color: '#fff',
        flexWrap: 'wrap',
        width: '90%'
    },
    table: { flex: 1, flexDirection: 'row', alignItems: 'center', paddingBottom: 5, borderBottomColor: '#5c6672', borderBottomWidth: 1 },
    /*    'table:last-child': {
           borderBottomWidth: 0
       }, */
    tableNoBorder: {
        borderBottomWidth: 0
    },
    pic: {
        width: '100%',
        resizeMode: 'contain',
    },
    tableColon: { alignSelf: 'center', width: '10%', textAlign: 'center' }
})

//make this component available to the app
export default Accordian;





/* -------------------------------------------------------hygiene */

//import liraries
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Animated } from 'react-native';
import TaskNavbar from '../../Components/Navbar/TaskNavbar';
import { Colors } from '../../Util/CommonStyle';
import { PinchGestureHandler, PanGestureHandler } from 'react-native-gesture-handler';

// create a component
const HygieneManual = ({ route }) => {
    const { header, item } = route.params;
    const [items, setItems] = useState(item);
    const [currentIndex, setCurrentIndex] = useState(0);
    const scale = React.useRef(new Animated.Value(1)).current;
    const translateX = React.useRef(new Animated.Value(0)).current;

    useEffect(() => {
        console.log('item', items);
    }, []);

    const prevNext = () => {
        if (currentIndex < 0 | currentIndex < items.length - 1) {
            setCurrentIndex(prev => prev + 1);
        } else if (currentIndex === items.length - 1) {
            setCurrentIndex(prev => prev - 1);
        }
    }

    const handlePinch = Animated.event([{ nativeEvent: { scale } }], { useNativeDriver: true })

    const handlePan = Animated.event([
        {
            nativeEvent: {
                translationX: translateX,
            },
        }
    ],
        {
            listener: (e) => console.log('hello', e.nativeEvent),
            useNativeDriver:true
        },

    )
    return (
        <View style={styles.container}>
            <TaskNavbar taskno={header} />
            {/*   {item.map((item, index) => ( */}
            <PanGestureHandler onGestureEvent={handlePan}>
                <Animated.View style={{ flex: 1 }}>
                    <PinchGestureHandler onGestureEvent={handlePinch}>
                        <Animated.Image style={[styles.pic, { alignSelf: 'center',/*  resizeMode: 'center', */ transform: [{ scale },{translateX}] }]} source={item[currentIndex]} />
                    </PinchGestureHandler>

                    <TouchableOpacity onPress={() => prevNext()} style={{ backgroundColor: Colors.primary, width: '90%', position: 'absolute', bottom: '6%', alignItems: 'center', marginHorizontal: '5%', borderRadius: 5 }}>
                        <Text style={{ color: '#fff', paddingVertical: 15 }}>{currentIndex === items.length - 1 ? 'Previous' : 'Next'}  </Text>
                    </TouchableOpacity>
                </Animated.View>
            </PanGestureHandler>

            {/*  ))} */}
        </View>
    );
};

// define your styles
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    pic: {
        height: '100%',
    }
});

//make this component available to the app
export default HygieneManual;

//import liraries
import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Pressable, Image } from 'react-native';
import { Data, DataRoutine } from './DummyData';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import ModalComp from './ModalComp';
import { FontFamily, Colors } from '../Util/CommonStyle';
import { useNavigation } from '@react-navigation/native';



// create a component
const Accordions = () => {
    const [currentIndex, setCurrentIndex] = React.useState(null);
    const [modalVisible, setModalVisible] = useState(false);
    const navigation = useNavigation();


    const renderItem = ({ item, index }) => {
        return (
            <View>
                <TouchableOpacity key={item.id} onPress={() => {
                    setCurrentIndex(index === currentIndex ? null : index);
                }}>
                    <View style={styles.headerCont}>
                        <View style={styles.header}>
                            <Text style={styles.headerText}>{item.question}</Text>
                            {index === currentIndex ? <MaterialIcons name='keyboard-arrow-up' color='#fff' size={32} /> : <MaterialIcons name='keyboard-arrow-down' color='#fff' size={32} />}
                        </View>
                    </View>   

                    {index === currentIndex && (
                        <View style={{}} >
                            <View style={{ padding: 10 }}>
                                {item.DataInner.map((item, i) => (
                                    <View style={{paddingBottom:10}}>
                                        <Text style={{ color:Colors.primary,paddingBottom:2 }}>{item.question}</Text>
                                        <TouchableOpacity onPress={()=>navigation.navigate('HygieneManual',{ header: item.question,item :item.DataInnerLayer})} style={{ backgroundColor: Colors.primary, width: '30%', alignItems: 'center', borderRadius: 10 }}>
                                            <Ionicons name='eye' color='#fff' size={32} />
                                        </TouchableOpacity>
                                    </View>
                                ))}
                                <ModalComp modalVisible={modalVisible} setModalVisible={setModalVisible} image={'item.image'} />
                            </View>
                        </View>
                    )}

                </TouchableOpacity>
            </View>
        )
    }

    return (
        <View style={styles.container}>
            <FlatList
                data={DataRoutine}
                renderItem={renderItem}
                keyExtractor={(item, index) => {
                    index.toString();
                }}
                style={{ flexGrow: 0, height: '90%' }}

            /* ListFooterComponent={renderLoader} */
            /*  onEndReached={loadMoreItem} */
            /* onEndReachedThreshold={0} */
            />
        </View>
    );
};

// define your styles
const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: 30,
        marginHorizontal:20
    },
    widthff: { width: '45%' },
    headerCont: {
        backgroundColor: '#5c6672',
        borderBottomColor: '#fff',
        borderWidth: 1,
        borderTopColor: '#738591'
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: '4%',
        paddingVertical: '1%'
    },
    headerText: {
        color: '#fff',
        flexWrap: 'wrap',
        width: '90%'
    },
    table: { flex: 1, flexDirection: 'row', alignItems: 'center', paddingBottom: 5, borderBottomColor: '#5c6672', borderBottomWidth: 1 },
    /*    'table:last-child': {
           borderBottomWidth: 0
       }, */
    tableNoBorder: {
        borderBottomWidth: 0
    },
    pic: {
        width: '100%',
        resizeMode: 'contain',
    },
    tableColon: { alignSelf: 'center', width: '10%', textAlign: 'center' }
});

//make this component available to the app
export default Accordions;



//import liraries
import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Pressable, Image } from 'react-native';
import { Data, DataRoutine } from './DummyData';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import ModalComp from './ModalComp';


// create a component
const Accordions = () => {
  const [currentIndex, setCurrentIndex] = React.useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  const renderItem = ({ item, index },...props) => {
    return (
      <View>
        <TouchableOpacity key={item.id} onPress={() => {
          setCurrentIndex(index === currentIndex ? null : index);
        }}>
          <View style={styles.headerCont}>
            <View style={styles.header}>
              <Text style={styles.headerText}>{item.question}</Text>
              {index === currentIndex ? <MaterialIcons name='keyboard-arrow-up' color='#fff' size={32} /> : <MaterialIcons name='keyboard-arrow-down' color='#fff' size={32} />}
            </View>
          </View>

          {index === currentIndex && (
            <View style={{ borderColor: '#5c6672', borderWidth: 2, borderRadius: 5, margin: 20 }} >
              <View style={{ padding: 15 }}>
                {item.DataInner.map((item, i) => (
                  <View>
                    <View style={(index === item.length - 1) ? styles.tableNoBorder : styles.table}>
                      <Text style={styles.widthff}>
                        {item.question}
                      </Text>
                      <Text style={{ alignSelf: 'center', width: '10%', textAlign: 'center' }}>:</Text>
                      <Text style={styles.widthff}>
                        {item.answer}
                      </Text>
                    </View>
                    <View style={styles.table}>
                      <Text style={styles.widthff}>Production Image</Text>
                      <Text style={styles.tableColon}>:</Text>
                      {item.image && <Pressable onPress={() => setModalVisible(true)} style={{ width: '40%', marginTop: '2%' }}>
                        <Image style={[styles.pic, { alignSelf: 'center', }]} source={item.image} />
                        <ModalComp modalVisible={modalVisible} setModalVisible={setModalVisible} image={item.image} />
                      </Pressable>}
                    </View> 
                  </View>
                ))}
                <ModalComp modalVisible={modalVisible} setModalVisible={setModalVisible} image={'item.image'} />
              </View>
            </View>
          )}

        </TouchableOpacity>
      </View>
    )
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={Data}
        renderItem={renderItem}
        keyExtractor={(item, index) => {
          index.toString();
        }}
        style={{ flexGrow: 0, height: '90%' }}

      /* ListFooterComponent={renderLoader} */
      /*  onEndReached={loadMoreItem} */
      /* onEndReachedThreshold={0} */
      />
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop:30
  },
  widthff: { width: '45%' },
  headerCont: {
    backgroundColor: '#5c6672',
    borderBottomColor: '#fff',
    borderWidth: 1,
    borderTopColor: '#738591'
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: '4%',
    paddingVertical: '1%'
  },
  headerText: {
    color: '#fff',
    flexWrap: 'wrap',
    width: '90%'
  },
  table: { flex: 1, flexDirection: 'row', alignItems: 'center', paddingBottom: 5, borderBottomColor: '#5c6672', borderBottomWidth: 1 },
  /*    'table:last-child': {
         borderBottomWidth: 0
     }, */
  tableNoBorder: {
    borderBottomWidth: 0
  },
  pic: {
    width: '100%',
    resizeMode: 'contain',
  },
  tableColon: { alignSelf: 'center', width: '10%', textAlign: 'center' }
});

//make this component available to the app
export default Accordions;


//import liraries
import React, { useEffect, useState, useContext ,useRef} from 'react';
import { View, Text, StyleSheet, Image, TextInput, TouchableOpacity, ActivityIndicator,Platform ,I18nManager} from 'react-native';
import CheckBox from '@react-native-community/checkbox';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import { AuthContext } from '../../Components/context';
import { signIn } from '../../Redux/actions/SI_Action';
import { useDispatch, useSelector } from 'react-redux';
import CustomeError from '../../Components/modals/CustomeError';
import { version } from '../../../package.json';


// create a component
const Login = ({ navigation }) => {
    const state=useSelector(state=>state);
    const dispatch = useDispatch()
    const [userEmail, setUserEmail] = useState('');
    const [userPassword, setUserPassword] = useState('');
    const [toggleCheckBox, setToggleCheckBox] = useState(false)
    const alertRef = useRef();
    /* const { signIn } = useContext(AuthContext); */

    const loginHandle = (userEmail,password) => {
      //  dispatch(signIn(userEmail,password));
      dispatch(signIn(userEmail,password,toggleCheckBox, (result) => {
        console.log('sssssss',result);
        alertRef.current.show(result.error);
    }));
    }

    useEffect(()=>{
        console.log('check',toggleCheckBox)
    },[toggleCheckBox])
    return (
        <View style={styles.container}>
            <View style={{ width: '80%', marginTop: '3%' }} > 
                <Image style={styles.Logo} source={require('../../assets/img/ADAFSA_LOGO.png')} />
                <View style={styles.selfIns}>
                    {I18nManager.isRTL?<Image style={styles.selfInsImage} source={require('../../assets/img/icons/arabicSelfinspectionLogo.jpeg')} />:<Image style={styles.selfInsImage} source={require('../../assets/img/icons/selfInspectionImage.jpg')} />}
                    
                </View>
                <View style={styles.userCont}>
                    <FontAwesome5 name="user-alt" color="gray" size={20} />
                    <TextInput
                        placeholder="Email Address"
                        value={userEmail}
                        placeholderTextColor="#bebebe"
                        style={styles.textInput}
                        autoCapitalize="none"
                        onChangeText={(val) => setUserEmail(val)}
                    />
                </View>

                <View style={styles.userCont}>
                    <FontAwesome5 name="lock" color="gray" size={20} />
                    <TextInput
                        placeholder="Password"
                        value={userPassword}
                        placeholderTextColor="#bebebe"
                        style={styles.textInput}
                        autoCapitalize="none"
                        secureTextEntry={true}
                        onChangeText={(val) => setUserPassword(val)}
                    />
                </View>

                <View style={styles.rememberMe}>
                    <CheckBox
                        disabled={false}
                        checkboxSize={10}
                        boxType={'square'}
                        value={toggleCheckBox}
                        onCheckColor={'#00ff0f'}
                        onTintColor={'#00ff0f'}
                        onValueChange={(newValue) => setToggleCheckBox(newValue)}
                    />
                    <Text style={{ paddingLeft: 10, color: 'gray' }}>Remember me</Text>
                </View>

                <TouchableOpacity style={styles.loginCont} onPress={() => {loginHandle(userEmail,userPassword)}/* navigation.navigate("Tabs") */}>
                    <Text style={styles.loginText}>
                        Login
                    </Text>
                </TouchableOpacity>
                <View style={{alignItems:'center',paddingTop:10,justifyContent:'center'}}>
                    <Text style={{color:'#aeaeae',paddingBottom:2}}>Version : {version ? version : '4.4'}</Text>
                    <Text  style={{color:'#bebebe',textAlign:'center',fontSize:12,letterSpacing:0.5}}>Please use your ADAFSA eService {"\n"} credentials, business operators can be added {"\n"} from eService Account </Text>
                </View>
            </View>  
            <CustomeError ref={alertRef} />

        </View>
    );
};

// define your styles
const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        backgroundColor: '#fff'
    },
    Logo: {
        width: '100%',
        resizeMode: 'contain',
        height: Platform.OS === 'ios' ? '40%':'22%',
    },
    selfIns: { height:80},
    selfInsImage: { alignSelf: 'center', height: '90%', resizeMode: 'contain' },
    userCont: {
        flexDirection: 'row', marginTop: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#c9ced4',
        paddingVertical: 15,
        marginTop: '8%'
    },
    rememberMe: {
        flexDirection: 'row', marginTop: 10,
        alignItems: 'center',
        paddingVertical: 15,
        marginTop: '5%'
    },
    inputStyle: {
        color: 'black',
        paddingLeft: 15,
        paddingRight: 15,
    },
    textInput: {
        flex: 1,
        marginTop: Platform.OS === 'ios' ? 0 : -12,
        paddingLeft: 20,
        color: '#5d6773',
        fontSize: 18,
        letterSpacing: 0.7
    },
    loginCont: { alignSelf: 'center', justifyContent: 'center', backgroundColor: '#5d6a73', paddingHorizontal: '20%', paddingVertical: '5%', marginTop: '4%', borderRadius: 5, borderBottomColor: '#c9ced4', borderBottomWidth: 4 },
    loginText: { color: '#fff', fontWeight: '600', fontSize: 18 }
});

//make this component available to the app
export default Login;


/* {"InterfaceID": "ADFCA_CRM_SBL_066",
		"AssesmentChecklist": {
			"Inpsection": {
				"DataLogger": "N",
				"Flashlight": "N",
				"LuxMeter": "N",
				"UVLight": "N",
				"TaskID": "1-721809638",
				"Thermometer": "N",
				"InspectorId": "SALEH.BALKHAIR",
				"InspectorName": "",
				"LanguageType": "ENU",
				"ListOfSalesAssessment": {
					"AssessmentChecklist": {
						"AssessmentScore": "",
						"Description": "",
						"MaxScore": "",
						"Name": "",
						"Percent": "",
						"TemplateName": "Direct Self Inspection-Food",
						"ListOfSalesAssessmentValue": {
							"AssessmentChecklistValues": [
								{
									"AttributeName": "Building cleanness",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "1",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
									"AttributeName": "Building Maintenance",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "2",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
									"AttributeName": "Hand wash Basin(s) &amp; facilities",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "3",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
									"AttributeName": "Ventilation",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "4",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
									"AttributeName": "Light protection and intensity",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "5",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
									"AttributeName": "Drainage facilities",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "6",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
									"AttributeName": "Staff toilets and changing facilities (where applicable)",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "7",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
									"AttributeName": "The floor Surfaces materials",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "8",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "The walls &amp; partition surfaces Materials",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "9",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "The ceiling surfaces materials",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "10",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "Windows &amp; other opining",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "11",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "Doors surfaces &amp; conditions",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "12",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "The working space and process work flow",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "13",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "Food Separation",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "14",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "Equipment kept clean and disinfectant (where applicable)",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "15",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "Equipment design and materials",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "16",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "Equipment maintenance and calibration",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "17",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "Equipment/tools/ facilities for Cleaning and disinfectant",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "18",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "Equipment/ facilities for waste disposal",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "19",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "Hand washing",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "20",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "Personnel health status, uniform &amp; Protective clothing",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "21",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "Personnel behaviors",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "22",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
								{
                                    "AttributeName": "Food Protected from Contamination",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "23",
									"Score": "",
									"Value": "yes",
									"Weight": "1",
								},
                                {
                                    "AttributeName": "Food Shelf life (No expired food)",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "24",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Food Storage Condition and temperature",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "25",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Raw materials, ingredients and food source",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "26",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Halal &amp; Non- Halal separation (where applicable)",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "27",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Display of unpackaged &amp; ready to eat food",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "28",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Packaging &amp; Wrapping Materials",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "29",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Food Washing facilities",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "30",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Pest Control",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "32",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Chemicals usage &amp; storage",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "33",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Cooking tep./ Past. Temp./ heat treatment",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "34",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Thawing Procedure (where applicable)",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "35",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Water and/or ice supply",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "36",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Food Transportation vehicle (where applicable)",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "37",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Traceability &amp; Recall system",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "38",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "ADFCA EFST Program",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "39",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "The food handler health status records",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "40",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Pest Control Program Records",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "41",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Temp, cleaning, maintenance &amp; calibration records.",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "42",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "Food Safety Management system (FSMS)",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "43",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                {
                                    "AttributeName": "ADFCA approvals/certificates and required licensing requirements",
									"Comment": "Satisfactory",
                                    "DateOfRecovery":"05/27/2022 13:53:11",
                                    "Description3":"",
									"Order": "44",
									"Score": "",
									"Value": "yes",
									"Weight": "1"
								},
                                
							]
						}
					}
				}
			}
		},
        "Attrib1":"Inspection Rejected",
        "Attrib2":"Direct Self Inspection",
        "Attrib3":"00:03:21",
        "Attrib4":"05/27/2022 13:53:11",
        "Attrib5":"05/13/2022 13:53:11"
	
} */


