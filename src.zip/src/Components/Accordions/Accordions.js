//import liraries
import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Pressable, Image } from 'react-native';
import { Data, DataRoutine } from '../DummyData';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Entypo from 'react-native-vector-icons/Entypo';
import ModalComp from '../modals/ModalComp';
import { Colors } from '../../Util/CommonStyle';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';
import CustomeError from '../modals/CustomeError';
import { useSelector, useDispatch } from 'react-redux';
import IconCont from '../IconCont';
import CommentModal from '../modals/CommentModal';

// create a component
const Accordions = ({ data, /* onPress  */ }) => {
  const [currentIndex, setCurrentIndex] = React.useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [Check, setCheck] = useState('check');
  const [No, setNo] = useState(false);
  const [NA, setNA] = useState(false);
  const [comment, setComment] = useState(false);
  const navigation = useNavigation();
  const alertRef = useRef();
  const state = useSelector(state => state);
  const get_Assessment = useSelector(state => state.get_Assessment);


  const _check = (input) => {
    if (input == 'check') {
      setCheck('check');
    } else if (input == 'no') {
      setCheck('no')
    } else {
      setCheck('na')
    }
  }

  const onsubmitComment = (text) => {
    console.log(text)
  }

  const renderItem = ({ item, index }) => {
    /*   return(
        <Text>{JSON.stringify(item)}</Text>
      ) */
    return (

      <View>
        <TouchableOpacity key={item.id} onPress={() => {
          setCurrentIndex(index === currentIndex ? null : index);
        }}>
          <View style={styles.headerCont}>
            <View style={styles.header}>
              <Text style={styles.headerText}>{item.title}</Text>
              {index === currentIndex ? <MaterialIcons name='keyboard-arrow-up' color='#fff' size={32} /> : <MaterialIcons name='keyboard-arrow-down' color='#fff' size={32} />}
            </View>
          </View>

          <>
            {index === currentIndex && (
              <View >
                {item.data.map((item, i) => (
                  <View key={i}>
                    <View style={{ borderColor: Check == 'check' ? 'green' : Check == 'no' ? 'red' : 'orange', borderWidth: 1, padding: 20, margin: '5%', borderRadius: 10 }}>
                      <View style={{ flexDirection: 'row', justifyContent: 'space-around', paddingBottom: '13%', paddingHorizontal: 10 }}>
                        <View style={{ flex: 1, flexDirection: 'row' }}>
                          <Text style={{ paddingRight: 10 }}>{i + 1})</Text>
                          <Text style={{ width: '90%' }}>{item.attributeNameField}</Text>
                        </View>
                        <IconCont size={25} iconName={'calendar-clock-outline'} />
                      </View>
                      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                        <TouchableOpacity onPress={() => _check('check')} style={{ backgroundColor: Check == 'check' ? 'green' : '#485865', borderRadius: 20, padding: 5 }}>
                          <MaterialCommunityIcons style={{}} name={'check-bold'} color='#fff' size={30} />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => _check('no')} style={{ backgroundColor: Check == 'no' ? 'red' : '#485865', borderRadius: 20, padding: 5 }}>
                          <MaterialCommunityIcons style={{}} name={'close-thick'} color='#fff' size={30} />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => _check('na')} style={{ backgroundColor: Check == 'na' ? 'orange' : '#485865', borderRadius: 30, fontSize: 16, padding: 11, }}>
                          <Text style={{ color: '#fff' }}  >N/A</Text>
                        </TouchableOpacity>
                        <TouchableOpacity /* onPress={ onPress()} */ style={{ backgroundColor: '#485865', borderRadius: 20, padding: 8 }}>
                          <Entypo style={{}} name='attachment' color='#fff' size={22} />
                        </TouchableOpacity>
                        <IconCont onPress={() => setModalVisible(true)} size={30} iconName={'notebook-edit'} />
                      </View>
                    </View>
                  </View>
                ))}
                <CommentModal visible={modalVisible} onClose={() => setModalVisible(false)} onsubmit={onsubmitComment} />
              </View>
            )}
          </>
        </TouchableOpacity>
      </View>
    )
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={data}
        renderItem={renderItem}
        keyExtractor={(item, index) => {
          index.toString();
        }}
        style={{ flexGrow: 0, height: '90%' }}

      /* ListFooterComponent={renderLoader} */
      /*  onEndReached={loadMoreItem} */
      /* onEndReachedThreshold={0} */
      />
    </View>
  );
};

// define your styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 30
  },
  widthff: { width: '45%' },
  headerCont: {
    backgroundColor: '#5c6672',
    borderBottomColor: '#fff',
    borderWidth: 1,
    borderTopColor: '#738591'
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: '4%',
    paddingVertical: '1%'
  },
  headerText: {
    color: '#fff',
    flexWrap: 'wrap',
    width: '90%',
    textAlign: 'center'
  },
  table: { flex: 1, flexDirection: 'row', alignItems: 'center', paddingBottom: 5, borderBottomColor: '#5c6672', borderBottomWidth: 1 },
  table2: { flex: 1, flexDirection: 'row', alignItems: 'center', paddingBottom: 5, },
  /*    'table:last-child': {
         borderBottomWidth: 0
     }, */
  tableNoBorder: {
    borderBottomWidth: 0
  },
  pic: {
    width: '100%',
    resizeMode: 'contain',
  },
  tableColon: { alignSelf: 'center', width: '10%', textAlign: 'center' }
});

//make this component available to the app
export default Accordions;

