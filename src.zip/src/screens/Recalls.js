//import liraries
import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity, ViewComponent } from 'react-native';
import Navbar from '../Components/Navbar/Navbar';
import AccordionsRecalls from '../Components/Accordions/AccordionsRecalls';
import SI_ImageCont from '../Components/SI_ImageCont';
import { Data, DataRoutine } from '../Components/DummyData'

//import Accordion from 'react-native-collapsible/Accordion';

// create a component
const Recalls = () => {

    return (
        <View style={styles.container}>
            <Navbar nav={'tab'} />
            <SI_ImageCont />
            <View style={{ height: '70%' }}>
                {/* <ScrollView> */} 
                    <AccordionsRecalls data={Data}/>
                {/* </ScrollView> */}
            </View>
        </View>
    );
};

// define your styles
const styles = StyleSheet.create({ 
    container: {
        flex: 1,
    },
    tabBarLogo: {
        width: '100%',
        height: '100%',
        resizeMode: 'contain',
    },
    imageCont: { height: '9%', marginVertical: 10, alignItems: 'center', justifyContent: 'center' },

});

//make this component available to the app
export default Recalls;
