//import liraries
import React, { Component, useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Dimensions } from 'react-native';
import Navbar from '../Components/Navbar/Navbar';
import TabToggle from '../Components/Navbar/tabToggle';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import SI_ImageCont from '../Components/SI_ImageCont';
import { IconLeftActiveRoutine, IconRightActive, IconRightInActive, IconLeftInActiveRoutine, ActiveScheduledTask, ActiveCompletedTask, InactiveScheduledTask, InactiveCompletedTask } from '../Util/CommonStyle'
import { useDispatch, useSelector } from 'react-redux';
import ModalCreateNewIns from '../Components/modals/ModalCreateNewIns';
import { AdhocInspection, Get_Assessment,GetCheckList } from '../Redux/actions/SI_Action';
import CustomeError from '../Components/modals/CustomeError';
import Loading from '../Components/Loading';

// create a component

const height = Dimensions.get('window').height;
const width = Dimensions.get('window').width;

const RoutineSelf = ({ navigation }) => {
    const dispatch = useDispatch();
    const [focusedScreen, setFocusedScreen] = React.useState(1);
    const Eshtablisment_Inspection_Type = useSelector(state => state.Eshtablisment_Inspection_Type);
    const [modalVisible, setModalVisible] = useState(false);
    const state = useSelector(state => state);
    const alertRef = useRef();


    const openTask = (taskId) => {
        dispatch(Get_Assessment(taskId, (result) => {
            console.log('sssssss', result);
            alertRef.current.show(result.error);
        }));
        dispatch(GetCheckList(taskId, (result) => {
            console.log('sssssss', result);
            alertRef.current.show(result.error);
        }));
    }

    return (
        <View style={styles.container}>
            {state.isLoading && <Loading />}
            <Navbar nav={'tab'} />
            <View>
                <TabToggle focusedScreen={focusedScreen} setFocusedScreen={setFocusedScreen} leftText={'Scheduled Tasks'} rightText={'Completed Tasks'} IconLeftActive={IconLeftActiveRoutine} IconRightActive={IconRightActive} IconLeftInActive={IconLeftInActiveRoutine} IconRightInActive={IconRightInActive} />
            </View>
            <SI_ImageCont />
            {focusedScreen == 1 ?
                <View style={{ alignItems: 'center', justifyContent: 'center'/* , flex: 1 */, }}>

                    <ScrollView style={{ height: height / 2, width: width / 1.05 }}>
                        {Eshtablisment_Inspection_Type.map((item, key) => (

                            <View style={{ width: '100%', borderColor: 'red' }}>
                                {(item.title === 'Routine Inspection' || item.title === 'Follow Up Self Inspection') &&
                                    <View>
                                        {item.data.map((item, index) => (
                                            (item.statusField !== 'Satisfactory' && item.statusField !=='Unsatisfactory')&&
                                            <TouchableOpacity key={index} onPress={() => openTask(item.inspectionNumberField)} style={styles.taskCont}>
                                                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', }}>
                                                    <Text style={styles.textWhite}>{item.priorityField ? item.priorityField : 'Medium'}</Text>
                                                    <Text style={styles.textWhite}>{item.inspectionNumberField}</Text>
                                                </View>
                                                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', paddingTop: '5%' }}>
                                                    <Text style={styles.textWhite}>{item.creationDateField}</Text>
                                                    <Text style={styles.textWhite}>{item.inspectionTypeField}</Text>
                                                </View>
                                            </TouchableOpacity>
                                        ))}
                                    </View>

                                }
                            </View>

                        ))}
                    </ScrollView>
                </View>

                : 
                <View style={{ alignItems: 'center', justifyContent: 'center'/* , flex: 1 */, }}>

                <ScrollView style={{ height: height / 2, width: width / 1.05 }}>
                    {Eshtablisment_Inspection_Type.map((item, key) => (

                        <View style={{ width: '100%', borderColor: 'red' }}>
                            {(item.title === 'Routine Inspection' || item.title === 'Follow Up Self Inspection') &&
                                <View>
                                    {item.data.map((item, index) => (
                                        (item.statusField === 'Satisfactory' || item.statusField =='Unsatisfactory')&&
                                        <TouchableOpacity key={index} onPress={() => openTask(item.inspectionNumberField)} style={styles.taskCont}>
                                            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', }}>
                                                <Text style={styles.textWhite}>{item.priorityField ? item.priorityField : 'Medium'}</Text>
                                                <Text style={styles.textWhite}>{item.inspectionNumberField}</Text>
                                            </View>
                                            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', paddingTop: '5%' }}>
                                                <Text style={styles.textWhite}>{item.creationDateField}</Text>
                                                <Text style={styles.textWhite}>{item.inspectionTypeField}</Text>
                                            </View>
                                        </TouchableOpacity>
                                        
                                    ))}
                                </View>

                            }
                        </View>

                    ))}
                </ScrollView>
            </View>


                }
        </View>
    );
};

// define your styles
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    taskCont: { backgroundColor: '#5c6672', paddingHorizontal: 10, borderRadius: 5, marginHorizontal: 10, marginVertical: 10, paddingVertical: 15 },
    textWhite: { color: '#fff', }
});

//make this component available to the app
export default RoutineSelf;
