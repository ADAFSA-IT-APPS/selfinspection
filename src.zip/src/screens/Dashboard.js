//import liraries
import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, Animated, Image, Button, TouchableOpacity, ScrollView, StatusBar, I18nManager, Platform, Dimensions } from 'react-native';
import Navbar from '../Components/Navbar/Navbar';
import TabToggle from '../Components/Navbar/tabToggle';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import ProgressCircle from '../Components/ProgressCircle';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import Config from "react-native-config";
import { GetCheckList, Search_Establishment_History, GetInspectionDetails, Get_Assessment } from '../Redux/actions/SI_Action';
import { FontFamily, Colors } from '../Util/CommonStyle';
import { toast, IconLeftActiveDaily, PendingtaskIcon, DownloadIcon, DelayedIcon, IconRightActiveDaily, IconLeftInActiveDaily, IconRightInActiveDaily, ActiveSelfIns, InactiveSelfIns, ActiveAdafsaIns, InactiveAdafsaIns, PendingTask, Delayed, InProgress } from '../Util/CommonStyle'
import SI_ImageCont from '../Components/SI_ImageCont';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import Loading from '../Components/Loading';
import CommentModal from '../Components/modals/CommentModal';
import Toast from 'react-native-root-toast';
import ToastComp from '../Components/ToastComp';

// create a component   
const height = Dimensions.get('window').height;
const width = Dimensions.get('window').width;
const Dashboard = ({ navigation }) => {
    const dispatch = useDispatch()
    const { t, i18n } = useTranslation();
    const state = useSelector(state => state)
    const Eshtablisment_Count = useSelector(state => state.Eshtablisment_Count)
    const [focusedScreen, setFocusedScreen] = React.useState(1);
    const [visible, setVisible] = useState(false)
    const [modalVisible, setModalVisible] = useState(false);


    /*     useEffect(() => {
            Animated.timing(fadeAnim, {
                toValue: 1,
                duration: 5000, 
                useNativeDriver: true
            }).start();          
        }); */
    useEffect(() => {
        // dispatch(Get_Assessment());
        /*   Toast.show('Please enter vehicle number', {
             duration: Toast.durations.SHORT,  
             position: 0,
         })  */
        toast('empty')

        dispatch(GetCheckList());
        dispatch(Search_Establishment_History());
        // Promise.all([dispatch(Get_Assessment()), dispatch(GetCheckList()), dispatch(Search_Establishment_History())])
    }, [dispatch])


    const onsubmit = (text) => {
        console.log(text)
    }
 
    const fadeAnim = useRef(new Animated.Value(0)).current;


    const Task = ({ icon, text, reading }) => {
        return (
            <>
                <StatusBar barStyle="dark-content" hidden={false} backgroundColor={Colors.primary} height='5' translucent={true} />
                <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: height / 55, marginHorizontal: '8%' }}>
                    {/*  <Logo width={120} height={20}/> */}
                    <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: height / 50 }}>
                        <View style={{ backgroundColor: Colors.primary, padding: 10, borderRadius: 150 }}>
                            {/* <MaterialCommunityIcons name="clipboard-check-outline" color='#fff' size={35} />
                             */}
                            {icon}
                        </View>
                        <Text style={{ paddingLeft: 15, fontSize: 16, paddingRight: 10 }}>{reading}</Text>
                    </View>
                    <Text style={{ fontSize: 12, fontWeight: '300', fontFamily: FontFamily.regular }}>{/* Config.ESERVICE_GENERIC */text}</Text>
                </TouchableOpacity>
                {/*      {state.isLoading && <Loading />} */}
            </>
        )
    }


    return (
        <View style={styles.container}>
            {state.isLoading && <Loading />}

            <Navbar nav={'tab'} />
            {/* <View> */}
            <TabToggle focusedScreen={focusedScreen} setFocusedScreen={setFocusedScreen} leftText={'Self Inspection'} rightText={'ADAFSA Inspection'} IconLeftActive={IconLeftActiveDaily} IconRightActive={IconRightActiveDaily} IconLeftInActive={IconLeftInActiveDaily} IconRightInActive={IconRightInActiveDaily} />
            {/*  </View> */}
            {focusedScreen == 1 ?
                <ScrollView style={{ flex: 1 }}>
                    {/* <Button onPress={() => setModalVisible(true)} title='open' />
                    <CommentModal visible={modalVisible} onClose={() => setModalVisible(false)} onsubmit={onsubmit} /> */}
                    <Animated.View style={[styles.container1,/*  { opacity: fadeAnim } */]}>
                        <SI_ImageCont />
                        <View style={{ alignItems: 'center' }}>
                            <ProgressCircle percentage={100} number={(Eshtablisment_Count.Satisfactory ? Eshtablisment_Count.Satisfactory.length : 0) + (Eshtablisment_Count.Unsatisfactory ? Eshtablisment_Count.Unsatisfactory.length : 0)} radius={height / 12} delay={500 + 100 * 1} max={100} strokeWidth={9} color={'#a0f04a'} textColor={'#000'} circle='1' />
                        </View>
                        <View style={styles.twoCircleCont}>
                            <View style={{ alignItems: 'center' }}>
                                <ProgressCircle percentage={80} number={Eshtablisment_Count.Satisfactory ? Eshtablisment_Count.Satisfactory.length : 0} radius={height / 15} color={'#a0f04a'} delay={500 + 100 * 1} max={100} textColor={'#000'} circle='2' />
                            </View>
                            <View style={{ alignItems: 'center' }}>
                                <ProgressCircle percentage={20} number={Eshtablisment_Count.Unsatisfactory ? Eshtablisment_Count.Unsatisfactory.length : 0} radius={height / 15} color={'#a0f04a'} delay={500 + 100 * 1} max={100} textColor={'#000'} circle='3' />
                            </View>
                        </View>
                        <View style={[styles.p10,]}>
                            <Task icon={DownloadIcon} text={t('In_Progress')} reading={Eshtablisment_Count.Open ? Eshtablisment_Count.Open.length : 0} />
                            <Task icon={PendingtaskIcon} text='Pending Tasks' reading={Eshtablisment_Count.Scheduled ? Eshtablisment_Count.Scheduled.length : 0} />
                            <Task icon={DelayedIcon} text='Delayed' reading='0' />
                        </View>
                    </Animated.View>
                    {/*  {state.isLoading && <Loading />} */}
                </ScrollView>
                : <ScrollView style={{ flex: 1 }}>
                    <Animated.View style={[styles.container1, /* { opacity: fadeAnim } */]}>
                        <SI_ImageCont />
                        <View style={{ alignItems: 'center' }}>
                            <ProgressCircle percentage={100} radius={height / 12} delay={500 + 100 * 1} max={100} strokeWidth={9} color={'#a0f04a'} textColor={'#000'} circle='1' />
                        </View>
                        <View style={styles.twoCircleCont}>
                            <View style={{ alignItems: 'center' }}>
                                <ProgressCircle percentage={80} radius={height / 15} color={'#a0f04a'} delay={500 + 100 * 1} max={100} textColor={'#000'} circle='2' />
                            </View>
                            <View style={{ alignItems: 'center' }}>
                                <ProgressCircle percentage={20} radius={height / 15} color={'#a0f04a'} delay={500 + 100 * 1} max={100} textColor={'#000'} circle='3' />
                            </View>
                        </View>
                        <View style={[styles.p10,]}>
                            <Task icon={DownloadIcon} text={t('In_Progress')} reading='5' />
                            <Task icon={PendingtaskIcon} text='Pending Tasks' reading='0' />
                            <Task icon={DelayedIcon} text='Delayed' reading='0' />
                        </View>
                    </Animated.View>
                </ScrollView>}

        </View>
    );
};

// define your styles
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    twoCircleCont: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', marginTop: -25, marginBottom: Platform.OS === 'ios' ? -height / 30 : -height / 70 },
    p10: { marginTop: Platform.OS === 'ios' ? '10%' : '1%' }

});

//make this component available to the app
export default Dashboard;






