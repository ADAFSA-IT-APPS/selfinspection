import React from "react";
import { View, Text, StyleSheet, Image } from "react-native";
import Navbar from "../../Components/Navbar/Navbar";
import SI_ImageCont from "../../Components/SI_ImageCont";

const Notifications = () => {
  return (
    <View style={styles.container}>
      <Navbar nav={'stacksWithoutLogout'} />
      <SI_ImageCont />
      <View style={styles.taskCont}>
        <Text style={styles.textWhite}>New Task Assigned:</Text>
        <Text style={styles.textWhite}>1-8364746738264</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  taskCont: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', backgroundColor: '#5c6672', paddingHorizontal: 10, borderRadius: 5, marginHorizontal: 10, marginVertical: 10, paddingVertical: 15 },
  textWhite: { color: '#fff' }
});
export default Notifications;
