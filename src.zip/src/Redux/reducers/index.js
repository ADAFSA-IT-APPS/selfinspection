import { combineReducers } from "redux";
import SI_reducer from './chatReducer';

export default combineReducers({
    SI_reducer,
    
})