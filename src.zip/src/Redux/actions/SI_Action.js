import React, { useEffect, useState } from 'react';
import axios from "axios";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Encrypt, getDateInUtc, getCurrentDate, GetAsync, SetAsync, removeAsync } from "../../assets/Helpers/helpers";
import Config from "react-native-config";
import { post } from '../requestmanager';
import NavigationService from '../../navigation/NavigationService';
import { dataAssesment } from '../../Components/DummyData'
import { toast, getUserdetails } from '../../Util/CommonStyle';
import { useDispatch } from 'react-redux';

const { COMMON_SERVICE, APP_SERVICE_URL, ESERVICE_GENERIC, SELFINSPECTION_SERVICE } = Config;

/* export const GetServerDateTime = () => async () => {

    const dateStringPar = getCurrentDate();
    let dateString = dateStringPar;
    const encryptedServerDatePar = Encrypt(dateString);
    let encryptedServerDate = encryptedServerDatePar;
    let ur = APP_SERVICE_URL + COMMON_SERVICE + "/" + encryptedServerDate + "/" + dateString + "/GetServerDateTime";
    console.log('getserverdateapi', ur);
    try {
        const msgArray = { val: 7 }
        axios({
            method: "POST",
            url: ur,
            data: JSON.stringify(msgArray),
            headers: {
                "Content-Type": "application/json",
            }
        })
            .then(function (response) {
                console.log(response)
                console.log('datefromserver', response.data.GetServerDateTimeResult.serverDate);
                const dateObj = response.data.GetServerDateTimeResult.serverDate;
                console.log('datesigninobj', dateObj);
                //global.DateObj = dateObj;
                return { date: dateObj };
            })
    } catch (e) { console.log('errorfrom datefunc', e.ErrorMsg) }
} */

export const getDateTimeFromServer = async () => {
    const dateStringPar = getCurrentDate();
    let dateString = dateStringPar;
    const encryptedServerDatePar = Encrypt(dateString);
    let encryptedServerDate = encryptedServerDatePar;
    let ur = APP_SERVICE_URL + COMMON_SERVICE + "/" + encryptedServerDate + "/" + dateString + "/GetServerDateTime";
    console.log('getserverdateapi', ur);

    try {
        const msgArray = { val: 7 }
        return withTimeout(
            10000,
            axios({
                method: "POST",
                url: ur,
                /*                 withCredentials: false,
                                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, */
                data: JSON.stringify(msgArray),
                mode: "cors",
                headers: {
                    "Content-Type": "application/json",
                }
            })
                .then((response) => {
                    let dateObj = response.data.GetServerDateTimeResult.serverDate;
                    console.log('responseFromDateMethod', response);
                    return { status: response.status, data: dateObj };
                })
                .catch((err) => {
                    console.error('error_from serverdate_in_then', err);
                })
        );

    } catch (e) { console.log('error_from serverdate_in_try', e.ErrorMsg) }

}

function withTimeout(msecs, promise) {
    const timeout = new Promise((resolve, reject) => {
        setTimeout(() => {
            reject(new Error("timeout"));
        }, msecs);
    });
    return Promise.race([timeout, promise]);
}


export const signIn = (userName, password, toggle, result) => async (dispatch) => {


    let userToken;
    userToken = null;

    const userNameEcrypted = Encrypt(userName);
    const userPasswordEcrypted = Encrypt(password);
    console.log('test');
    const dateob = await getDateTimeFromServer();
    console.log('new111 date object', dateob);
    console.log('new date object', dateob.data);


    const dateInUtc = getDateInUtc(dateob.data);
    const encryptedServerDate = Encrypt(dateInUtc);

    let postUrl = APP_SERVICE_URL + ESERVICE_GENERIC + "/" + encryptedServerDate + "/" + dateInUtc + "/" + "DoLogin";
    console.log('mainurl', postUrl);
    if (userName === '') {
        return result({ error: 'Please enter Username' })
    } else if (password === '') {
        return result({ error: 'Please enter Password' })
    }
    let postData = { UserName: userNameEcrypted, Password: userPasswordEcrypted };
    console.log('userdata', postData);

    dispatch({ type: 'SHOW_LOADER' });

    try {
        return withTimeout(
            8000,
            axios({
                method: "POST",
                url: postUrl,
                mode: "cors",
                data: JSON.stringify(postData),
                headers: {
                    "Content-Type": "application/json",
                }
            })
                .then(async function (response){
                    dispatch({ type: 'HIDE_LOADER' });
                    console.log('response_from _login', response.data.DoLoginResult.UserAccountDetails);
                    console.log('response', response.data.DoLoginResult.ErrorCode);
                    console.log('response_from _STUlogin', response.status);



                    if (response.data.DoLoginResult.ErrorCode == "0") {
                        console.log('enter');
                        let userDetails = response.data.DoLoginResult.UserAccountDetails.CompanyInfo;
                        let errorCode = response.data.DoLoginResult.UserAccountDetails.ErrorCode;
                        console.log('errorCode', errorCode);

                        let ErrorMsg = response.data.DoLoginResult.UserAccountDetails.ErrorMsg;
                        // userToken = userDetails.DeviceToken;
                        if (errorCode == 0) {
                            userToken = 'asdf';
                            await AsyncStorage.setItem('userToken', userToken)
                            let userdetails = JSON.stringify(userDetails);
                            await AsyncStorage.setItem('userdetails', userdetails)
                            console.log('token_login', userToken);
                            /*  let testUser= await AsyncStorage.getItem('userdetails')
                             console.log('userdetails',testUser ); */
                            dispatch({ type: 'LOGIN', id: userName, token: userToken, UserAccountDetails: userDetails });
                        }
                        else if (errorCode == 1001) {
                            return result({ error: ErrorMsg })
                        }
                        else if (errorCode == 1002) {
                            return result({ error: ErrorMsg })
                        }
                        else if (errorCode == 1003) {
                            return result({ error: ErrorMsg })
                        }
                        else if (errorCode == 1004) {
                            return result({ error: ErrorMsg })
                        }
                    }
                    else if (response.data.DoLoginResult.ErrorCode == "101") {
                        return result({ error: 'Please correct time on your device' })
                    }
                    else if (response.data.DoLoginResult.ErrorCode == "102") {
                        return result({ error: 'Please correct date&time on your device' })
                    }
                    else if (response.data.DoLoginResult.ErrorCode == "103") {
                        return result({ error: 'Dear employee,this service has been stopped temporary' })
                    } else if (response.data.DoLoginResult.ErrorCode == "104") {
                        return result({ error: response.data.DoLoginResult.UserAccountDetails.ErrorMsg })
                    }
                    else if (response.data.DoLoginResult.ErrorCode == "404") {
                        return result({ error: 'Dear Customer, we are unable to load. Please try again later. Sorry for the inconvenience caused. ' })
                    }
                    else if (response.data.DoLoginResult.ErrorCode == "402") {
                        return result({ error: 'Dear Customer,server error occured. Please try again later.' })
                    }
                    else {
                        console.log('nodata');
                        return result({ error: 'No_Data_Found' })
                    }
                })
                .catch((err) => {
                    //    dispatch({ type: 'HIDE_LOADER' });
                    console.log('error_from login_in_then', err.ErrorMsg);
                    return result({ error: err.ErrorMsg })

                })
        );

    } catch (e) {
        dispatch({ type: 'HIDE_LOADER' });
        console.log('error_from login_in_catch', e.ErrorMsg);
    }

};

export const Search_Establishment_History = () => async (dispatch) => {
    console.log('');
    dispatch({ type: 'SHOW_LOADER' });

    const dateob = await getDateTimeFromServer();

    const dateInUtc = getDateInUtc(dateob.data);
    const encryptedServerDate = Encrypt(dateInUtc);


    let postUrl = APP_SERVICE_URL + SELFINSPECTION_SERVICE + "/" + encryptedServerDate + "/" + dateInUtc + "/" + "Search_Establishment_History";

    console.log('Search_Establishment_History', postUrl);
    const userdetails = getUserdetails();
    console.log('checkuserdetails', userdetails);
    let postData =
    {
        _Input: {
            InterfaceID: "ADFCA_CRM_SBL_005",
            LanguageType: "ENU",
            TradeLicenseNumber: "CN-1700160",
            InspectorName: "",
            LicenseSource: "",
            EnglishName: "",
            InspectorId: "",
            ArabicName: "",
            AdditionalTag1: "",
            Sector: "",
            AdditionalTag2: "",
            Area: "",
            AdditionalTag3: ""
        }
    };

    try {
        axios({
            method: "POST",
            url: postUrl,
            data: JSON.stringify(postData),
            headers: {
                "Content-Type": "application/json",
            }
        })
            .then(function (response) {
                console.log('Search_Establishment_HistoryResult_response', response.data.Search_Establishment_HistoryResult);
                let data = response.data.Search_Establishment_HistoryResult.Search_Establishment_History_Output.tradelicenseHistoryField[0].listOfActionField;
                console.log('Search_Establishment_HistoryResult', data);
                let dataObjCount = {};
                data.forEach(e => {
                    if (dataObjCount[e.statusField]) {
                        dataObjCount[e.statusField].push(e)
                    } else {
                        dataObjCount[e.statusField] = [e]
                    }
                });
                let dataObjInspection = {};
                data.forEach(e => {
                    if (dataObjInspection[e.inspectionTypeField]) {
                        dataObjInspection[e.inspectionTypeField].push(e)
                    } else {
                        dataObjInspection[e.inspectionTypeField] = [e]
                    }
                });
                const formattedObj = Object.values(dataObjInspection).map((item, index) => ({
                    title: item[0].inspectionTypeField,
                    data: item
                }
                ))

                console.log('count', dataObjCount/* .Acknowledged.length */);
                dispatch({ type: 'HIDE_LOADER' });
                if (response.data.Search_Establishment_HistoryResult.Search_Establishment_History_Output.statusField == "Success") {
                    console.log('enterhistory')
                    dispatch({ type: 'SEARCH_ESHTABLISHMENT_RESULT', payload: data, eshtablish_count: dataObjCount, eshtablish_inspection_type: formattedObj });
                    // toast('Success')

                } else {
                    toast('FAILURE')

                    console.log('wrong');
                    return
                }
            })
          /*   .catch((err) => {
                dispatch({ type: 'HIDE_LOADER' });

        }) */
    } catch (e) {
        // console.log('GET_INSPECTION_DETAILS_ERROR', e.ErrorMsg);
       // dispatch({ type: 'HIDE_LOADER' });
        return result({ error: e.ErrorMsg })

    }

    // dispatch({ type: 'GET_CHECK_LIST', payload: false });
}

export const AdhocInspection = (IType, VNumber) => async (dispatch) => {
    console.log('itype', IType);
    console.log('VNumber', VNumber);
    dispatch({ type: 'SHOW_LOADER' });



    // dispatch({ type: 'SHOW_LOADER' });

    const dateob = await getDateTimeFromServer();

    const dateInUtc = getDateInUtc(dateob.data);
    const encryptedServerDate = Encrypt(dateInUtc);  


    let postUrl = APP_SERVICE_URL + SELFINSPECTION_SERVICE + "/" + encryptedServerDate + "/" + dateInUtc + "/" + "AdhocInspection";

    console.log('AdhocInspection', postUrl);
    let postData = {
        _Input: 
        {
            InterfaceID: "ADFCA_CRM_SBL_034",
            Longitude: "",
            PostalCode: "",
            Address2: "",
            InspectionType: IType,
            AccountArabicName: "",
            PhoneNumber: "",
            LanguageType: "",
            City: "",
            TradeLicenseNumber: "CN-1700160",
            Latitude: "",
            InspectorName: "SADMIN",
            AccountName: "Test Farm",
            Score: "",
            MailAddress: "",
            Address1: "",
            AccountType: "Customer",
            Action: "",
            LicenseExpDate: "",
            InspectorId: "",
            LicenseRegDate: "",
            Grade: VNumber ? VNumber : ''
        }

    };

    try {
        axios({
            method: "POST",
            url: postUrl,
            data: JSON.stringify(postData),
            headers: {
                "Content-Type": "application/json",
            }
        })
            .then( (response)=>{
                console.log('adhocResponse', response.data.AdhocInspectionResult);
                let data = response.data;
                console.log('Adhocdata', data);

                if (response.data.AdhocInspectionResult.NewInspection_Output.statusField == "Success") {
                    dispatch({ type: 'ADHOC_INSPECTION', payload: data });
                    toast('Success')
                    dispatch({ type: 'HIDE_LOADER' });

                    let taskid = response.data.AdhocInspectionResult.NewInspection_Output.taskIdField
                    dispatch(Get_Assessment(taskid));
                    dispatch(GetCheckList(taskid));
                    // NavigationService.navigate('TaskDetails', { taskId: taskid });
                    // return result({ error: response.data.AdhocInspectionResult.NewInspection_Output.statusField })
                } else {
                    toast('FAILURE');
                    dispatch({ type: 'HIDE_LOADER' });

                    return;
                    console.log('wrong');
                    return //result({ error: response.data.AdhocInspectionResult.NewInspection_Output.statusField })
                }
            }).catch((err) => async (dispatch) => {
                dispatch({ type: 'HIDE_LOADER' });

        })
             
             
    } catch (e) {
        console.log('GET_INSPECTION_DETAILS_ERROR', e.ErrorMsg);
        dispatch({ type: 'HIDE_LOADER' });

    }
 
    // dispatch({ type: 'GET_CHECK_LIST', payload: false });
}

export const Get_Assessment = (TaskId, result) => async (dispatch) => {
    console.log('task_Get_Assessment', TaskId);
    dispatch({ type: 'SHOW_LOADER' });

    const dateob = await getDateTimeFromServer();

    const dateInUtc = getDateInUtc(dateob.data);
    const encryptedServerDate = Encrypt(dateInUtc);


    let postUrl = APP_SERVICE_URL + SELFINSPECTION_SERVICE + "/" + encryptedServerDate + "/" + dateInUtc + "/" + "Get_Assessment";

    console.log('Get_Assessment', postUrl);
    let postData = {
        _Input: {
            InterfaceID: "ADFCA_CRM_SBL_065",
            LanguageType: "ENU",
            InspectorName: "",
            TaskId: TaskId,
            InspectorId: "",
        }
    };
    console.log('payload_getAssement', postData);
    try {
        axios({
            method: "POST",
            url: postUrl,
            data: JSON.stringify(postData),
            headers: {
                "Content-Type": "application/json",
            }
        })
            .then(function (response) {
                console.log('Get_AssessmentResponse', response.data.Get_AssessmentResult);
                const data = response.data.Get_AssessmentResult.GetAssesment_Output.listOfAdfcaMobilitySalesAssessmentField[0].listOfSalesAssessmentAttributeField;
                AsyncStorage.setItem('dataAssessmentt', JSON.stringify(data))

                /*   let dataObj = {};
                  data.forEach(e => {
                      if (dataObj[e.descriptionField]) {
                          dataObj[e.descriptionField].push(e);
                      } else {
                          dataObj[e.descriptionField] = [e];
                      }
                  });
                  const formattedObj = Object.values(dataObj).map((item, index) => ({
                      title: item[0].descriptionField,
                      data: item
                  }
                  )) */
                console.log('Get_Assessment--------'/* dataObj */ /* JSON.stringify(formattedObj) */);

                // dispatch({ type: 'HIDE_LOADER' });

                if (response.data.Get_AssessmentResult.ErrorDesc !== "Failed") {
                    console.log('comi------', TaskId);
                    // dispatch({ type: 'GET_ASSESSMENT', payload: formattedObj/*  payload: {data:formattedObj,loading:false}  */ });

                    dispatch({ type: 'HIDE_LOADER' });
                    //  NavigationService.navigate('TaskDetails', { taskId: TaskId });

                } else {
                    console.log('wrong');
                    return result({ error: ErrorMsg })
                }
            })
    } catch (e) {
        //console.log('GET_INSPECTION_DETAILS_ERROR', e.ErrorMsg);
       // dispatch({ type: 'HIDE_LOADER' });
    }

    // dispatch({ type: 'GET_CHECK_LIST', payload: false });
}

export const GetInspectionDetails = () => async (dispatch) => {
    console.log('');
    // dispatch({ type: 'SHOW_LOADER' });

    const dateob = await getDateTimeFromServer();

    const dateInUtc = getDateInUtc(dateob.data);
    const encryptedServerDate = Encrypt(dateInUtc);


    let postUrl = APP_SERVICE_URL + SELFINSPECTION_SERVICE + "/" + encryptedServerDate + "/" + dateInUtc + "/" + "Get_Inspection_Details";

    console.log('getchecklist', postUrl);
    let postData = {
        _Input: {
            Attribute1: "1-7SCZKK",
        }
    };

    try {
        axios({
            method: "POST",
            url: postUrl,
            data: JSON.stringify(postData),
            headers: {
                "Content-Type": "application/json",
            }
        })
            .then(function (response) {
                console.log('getcl', response.data.Get_Inspection_DetailsResult.Get_Inspection_Details_Output.getTaskField);
                let data = response.data.Get_Inspection_DetailsResult.Get_Inspection_Details_Output.getTaskField[0];
                console.log('data', data);
                dispatch({ type: 'HIDE_LOADER' });
                console.log('getmethod_inside');

                if (response.data.Get_Inspection_DetailsResult.ErrorCode == "0") {
                    dispatch({ type: 'GET_INSPECTION_DETAILS', payload: data });
                } else {
                    console.log('wrong');
                    return result({ error: response.data.Get_Inspection_DetailsResult.Get_Inspection_Details_Output.statusField })
                }
            })
    } catch (e) {
        console.log('GET_INSPECTION_DETAILS_ERROR', e.ErrorMsg);
       // dispatch({ type: 'HIDE_LOADER' });
    }
}

export const GetCheckList = (TaskId, result) => async (dispatch) => {
    dispatch({ type: 'LOADER' });
    console.log('task_GetCheckList', TaskId);

    const dateob = await getDateTimeFromServer();

    let dateInUtc = getDateInUtc(dateob.data);
    const encryptedServerDate = Encrypt(dateInUtc);

    let postUrl = APP_SERVICE_URL + SELFINSPECTION_SERVICE + "/" + encryptedServerDate + "/" + dateInUtc + "/" + "Get_Check_List";
    console.log('GetCheckList', postUrl);

    let postData = {
        _Input: {
            InterfaceID: "ADFCA_CRM_SBL_067",
            LanguageType: "ENU",
            InspectorName: "",
            TaskId: TaskId,
            InspectorId: "",
        }
    };

    try {
        axios({
            method: "POST",
            url: postUrl,
            data: JSON.stringify(postData),
            headers: {
                "Content-Type": "application/json",
            }
        })
            .then(function (response) {
                var data = response.data.Get_Check_ListResult.Get_Check_List_Output.inspectionCheckListField[0].listOfSalesAssessmentField[0].listOfSalesAssessmentValueField/* .inspectionCheckListField[0].listOfSalesAssessmentField[0].listOfSalesAssessmentValueField */;
                console.log('checkdata', data);

                if (response.data.Get_Check_ListResult.ErrorCode == "0") {
                    if (response.data.Get_Check_ListResult.Get_Check_List_Output.inspectionCheckListField[0].listOfSalesAssessmentField) {
                        AsyncStorage.getItem("dataAssessmentt").then((value) => {
                            let valueFormatted = JSON.parse(value);
                            const dataObj = data.map(item => {
                                const filteredData = valueFormatted.filter(e => e.nameField === item.attributeNameField)
                                console.log('filterdata', filteredData);
                                if (filteredData.length) {
                                    return {
                                        ...item,
                                        Description3: filteredData[0].descriptionField
                                    }
                                }
                            });


                            let DataObj = {};
                            dataObj.forEach(e => {
                                if (DataObj[e.Description3]) {
                                    DataObj[e.Description3].push(e);
                                } else {
                                    DataObj[e.Description3] = [e];
                                }
                            });
                            const formattedObj = Object.values(DataObj).map((item, index) => ({
                                title: item[0].Description3,
                                data: item
                            }
                            ))

                            dispatch({ type: 'GET_CHECK_LIST', payload: formattedObj });
                            dispatch({ type: 'HIDE_LOADER' });
                            // toast('Success')

                            console.log('formattedObj', JSON.stringify(formattedObj));

                            console.log('TaskIdfrom action in checklist', TaskId);

                            NavigationService.navigate('TaskDetails', { taskId: TaskId });

                            console.log('dataObj', dataObj);
                        })
                            .then(res => {
                                //do something else
                            });
                    } else {
                        toast('Network Error');
                    }


                } else {

                    return result({ error: response.data.Get_Inspection_DetailsResult.Get_Inspection_Details_Output.statusField })
                }
            })
    } catch (e) { console.log('GET_CHECK_LIST_ERROR', e.ErrorMsg); }

    // dispatch({ type: 'GET_CHECK_LIST', payload: false });
}

export const Add_Questionnaires_Attachment = (TaskId) => async (dispatch) => {
    console.log('Add_Questionnaires_Attachment123', TaskId);
    dispatch({ type: 'SHOW_LOADER' });

    const dateob = await getDateTimeFromServer();

    const dateInUtc = getDateInUtc(dateob.data);
    const encryptedServerDate = Encrypt(dateInUtc);


    let postUrl = APP_SERVICE_URL + SELFINSPECTION_SERVICE + "/" + encryptedServerDate + "/" + dateInUtc + "/" + "Add_Questionnaires_Attachment";

    console.log('Add_Questionnaires_Attachment', postUrl);
    let postData = {
        _Input: {
            InterfaceID: "ADFCA_CRM_SBL_039",
            LanguageType: "ENU",
            InspectorId: "",
            InspectorName: "",
            Checklistattachment: [
                {
                    TaskId: TaskId,
                    ListOfActionAttachment: [
                        {
                            FileAutoUpdFlg: "",
                            FileDeferFlg: "",
                            FileDockReqFlg: "",
                            FileDockStatFlg: "",
                            FileExt: "jpeg",
                            FileName: "85504858999",
                            FileSize: "",
                            FileSrcPath: "",
                            FileSrcType: "",
                            Comment: "",
                            FileBuffer: "iVBORw0KGgoAAAANSUhEUgAAApAAAAE8CAYAAAB3g4FYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAABNFSURBVHhe7d19zK91XQdwRFs0yYmyIMWGRZOKLUymVqxRnlozVpRsUcNmi6ZttnTzDzbdslGjaY02bdhoucaaNWzYsKGSQ8PEhooJCOUDFOYDoKFSPqH2fl+/35V3tzfnvs79+Ht4vbb3ftd1nfsczuH+nf0+5/N9Og4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4Ro+avwKw+k6b54Tk9D7Y4OHk3uRzyYPJPQnAlhSQAKvhxOTMec5Injx/7fP7kmcmJydH8/nkcbPL//Px5K7kA8nfJ+9JvpQAa0wBCbA8Wgw+Jjk7eXzSAvHH5/ebO4ofSVr83Z68P/lqUn3+qdnl4NSkv047ky0wT5lfN32+2XuTP03enDzQB8D6UUACHJ4Wb2clY6fw+5IWiKMOK49Dzi0YP5O0YOzXjlrEtShsofjWpN3C3u9Vl7D/7XY1z02ek5yXfDl5dPKm5LcTHUlYMwpIgP3XorDdvWcnz0o6pPwjyYVJO3oPJRu7ghu1iOzP77zEO/og+uwdSX/OQRdv/XO0mPzl5KKkv5eXJq9NAADYoXbsXpBcndyafDG5f359RdJC8pxkmbWo/dnktuQbyfVJu6QAAEzU4ejLkzuTFlTNjcmlyZFkuwUsy6rD6Tcn/fPekigiAQC20U7jTUkXqXwyuTJpwdi5g+uiRWP/H7SI7FZAP5YAALBBi8NXJB2WbtF0TdL5jOtUNG7WTuTbkw7Xt5h+UQIAsPa6aOR1SQvHu5MWSas6NL1T1yUtIMfCep2LagBgTXVuY+cx/lfS4dmXJ93KhkfW7uwXkhaRLba72AYAYKW1a9Yh6XbQ2k3r/L5LEt206Vo0tuBuEdm8MgEAWDktELsopoVPF8RclnSjb3am3dsOaY9FZDuTAAAro3szdgue7mtoAcje6X6R/f85zovsPFIAgKXWrmOHV9txbPeR/XF+0vmQXaVtr0gAYGmdntyQdJi1p8ewv7o/5vuTbjgOALB0OmTdwvElwx0H5YKkncge6QgAsDS6wrrnVNuO53BclXROZIe1AQAWWlcFt3BsAXNGH3AoOgeyG7F3tbutkQCAhdU5jjcntyan9QGH6uKkq7JNIQAAFlK7jWPHywrgxdFivt+TbvUDALAw2m3sFj09itCw9WLp6T7tQto+CQBYGJ1f183BW6Q4j3nx9PvTwr6dSACAhXBl0uKxi2ZYTK9O+j2yIhsAOHTdqqeFSec+ntgHLKRu5t7vUxc4mQsJAByabtfTzaoNXS+Hbq3U79WvDncAAIfg2qQFSQsTFl+7kB9NHkx0iwGAA/fKpMXjhxNb9iyPHm3Y79sbhjsAgAPSowlbhHwx6VnXLI/xdJp+/y7tAwCA/XZO0i1hWoC8qA9YOi36v5D0nOxz+wAAYL90Dl2HrFs8dlsYllc3Fe/3sft3WpUNAOyLjcWjRTOrYdy/s1sxAQDsqTOTdqo65Pl3iY7VauhK7Pcltw93AAB75KKkZ1y3U9VtexSPq6XnZHc+pMVQAMCu9fzky5MWjk2HO1k9JyddTW9aAgCwK2clPfKuhWNXXL8kYXW1eOz0BPt5AgA70m1dxuMJO++xxSSrrcdQ9vv94uEOAOAYXJyMQ9ZXJTpS66HzWttpvnG4AwCYqItlOozZ+XAv6wPWyvVJv/fOyAYAJukK3HagWkB2g2nWT+e5tvN8/nAHAHAU3SD8I0mLB0cTrq+zk74HnDAEABxVt+q5JWnh8Md9wNrqPMh7k542BADwiMaj7G5IbBDOa5K+H6y8BwC21O16Wiz0FJLT+oC1N27n86rhjsPSf9j9R3JHYloJAAulq25bLFw43MHMrcmnE6uxD8fzkv693JgjCWvq+PkrwCI4NWm36Z7kjX0Ac29JvitxNvbhOGn+utHPzF9ZQwpIYJG0eKy/nr/C6K3z19+Zv3Kw+o+7zb4yfwWAQzUuljA0xlZ6hGXfHxbTHKwzku7FunH4+svJVkUlABy4DyT9cHJUIVsZNxW/YrjjoLw92Vg8Nv1eAMCha9H4UHLXcAffqu+RnkzUFfoW0xyM5ySbi8ebEgBYCN2ypx9ONw53sLXLk75PLh3u2E/9O/nJZHPxqHgHYGGMe/1dN9zB1jrvrvPx7k5sMr9/+v+2G/lvLB67xZbiEYCF8uKkH1LXDnfwyK5O+l4ZV+2z98YFbWOuSQBg4bws6QeVDiTbOTPxXtk/f5FsLB7b7T05AYCFc0nSDysT9Jmiw6kdyrZif+90eHo8h35M50C2YAeAhXR+0g+s+4c7OLruFdr3izOZ90aLx5uTjcXjxxPFIwAL7dykH1pfTE7oA9jG25LbZpfsQo+H3Lza+qrEghkAFt64urYx34opXpB0T0hdsp3r3OPNp8z0GQAshXYdu0l0P8AckcYUPWKvHWsn0xy7/r/ryuqNhWO7uR0JAICl0X3nxmG00/sAJuhK7P7Dw56Q012QdK7xxuKxxaR/uAGwdNqB7FGG/TA7qw9ggguTvme6CIuj6/nVtyRfTjYWjl2QBABLqR2kTycPJ0/rA5ig//DoMLaNrrfWbv5lyYeTsWhsx/ZVSY8qBICl1gKyCyL6AXd2H8BEb0jsCflNLarbVdw8x7Hdxy48AoCV0flX4wedI+o4Fhclfd+s+56QnfpxabJ5S57u79h5j7blAWDldOue8QOv89pgqnavOyx7w3C3XvoPrxaN7S5uLBq7SKanynSPRwBYWR1+HD/82i2BY9FiaV2GsTtE3aHoHufY+Z/j35t2HrsBeDv4/RoAWHkKSHajRVPfO6s8x68rzV+R9ASe8e9Ku67tQJ6T2MoIgLXTAnI8EcMcSI5Vi6d24K4d7lZD/0xdUNZV1Hcn/ftxa9IuYwtlBSMAa68F5Dgcp4BkJ16dtMha9sUi3Xqnxwm2WOzfh/6ZXp/078U6DNEDwGT9YOwekP3AtCk0O9Fh3L5/uip72bTofXGycTFM5zgu458FAA5Mh+rGD84X9gHsQM9zXpZh7A5Bd8eBcR/Lvvf7+++cxp5VDQBsY1wE0fTINdiJDv12Q/pFnR/YbXc6f7FF47hxfruOHX635Q4AHKMOW48FZD9MYSfGubQXD3eLod3EFo3tjHa/ynHPyha7Oo0spePnrwCHbePCB3vYsVMPJn+WPHe4Oxw9EaZTMn4l6UKYrqJ+RvJPyS8mT01+Ovmj5CMJALBD7dCMHciuOIWdOi/pXMKDWrHcLmL/m30PX51cl3RKRtMhawBgnygg2SstHLsnZN9T++HM5JKk8xjHfRl7DneLyB7JCQAckG5XMhaQPZYOdqPvoZtnl7vSqRXtJL4y6RzGFqbjohcnJgHAIfu1ZCwg/6oPYBe6ornvpXYLp2rnsnMXuwvANUm7i/cnNyWXJy0knf4CAAukZ/yOBWTnkMFutNBrt7CF32YtFDtvsQVhi8V2K+9N+vXtWr4m6fMWk8AWHjV/BThs3Tx5/LD/8+Q3Z5ewY1cknRrx/OS05Ifnrz0q8IHk48m/J7cnd80DACyRftiPHchew1TtKHbrnOZI0pXQnbP4l0nfT29Mus9oO4otIG0TBbukAwksihaN4wk0r0t+a3YJg65u7pY47R4+K2kR+KX5a59/NPmH+f2nknYV687kPcmvD3fAnlBAAovi95OXzy6HzZW/f3bJCusK56ZFYQvEvrabeEoyFot9fSh5b9Jh5/9M+v7ocHPvW0T2xx9Jp0b8bnJS0q8F9oACElgUnff4G7PLQQtIp3QspxaBLQibDhl3JfRjky5c6X31tafGjGnXsAXhp5N75td9ttv3QP87XSDTObV9jwF7QAEJLIrOWWunaPQnyUtnlyyYsThsR69dwm6g3QUp9UNJC8gOKbcIfDhpgdgf73VfWxgepK7qb6fzJ4c7YNcUkMCiuDjp4ofRfUmHMjl4LbbauevwcbuGnVf45KQF4GeSJyafS96c9Gs7hLzIK5gvTLqv43cnB128wkpSQAKLogVLhy4fPdzN/EHS/SHZe2OR2OHlZyTtKPZZVyqPQ8f/mvR70uKwz1ootohcNi2AO4z9e8lr+wDYHQUksEjuSH5wdjn472QcKmVn2kFsxkUpT0taNLYYbHHYoeauWG6BOC5MWUXdLLyn0zx9uAN2RQEJLJIfTXps3MYuZOfUfWh2yRZaYLcgbOHXjuLzkm6OXZ0C0I5h889JC8bOQVzVIvFozkl6hvUPJDYMh11SQAKL5t+SjVv4fC15U9K9IT+QrFvx0yP5xi7iuM3N9yUdlq12ZzvU/JakX9v7FootGnVu/7+ebf03yR8Od8COKSCBRXNB8rfJ8cPdt+qK3s8m7046/Fpjp60LO8bCafNiiT7rsO34vMVYf60WYmP6c8fCbPx1+trCbNxqpj/en9tittf9sb62sN1YsG2+79d1jmG/tl3D/lq97+kpve6v2Q5iF6uMi1fGeYrjPMT3zV87P7E/p78nprskeWHSTne/r8AOKSCBRdQCqkOxLaKekzwlaedtO50z2f0Gx6KvWmSNhVYLuhZjXVDRLV1aUI5F4Pj1G/XXGX+tFoQd/u0q5P6eWsSNC0/62t/f5l9jLEDH9Nfo1/XXeVfSH++ilXcm43+jX9cf7+9zLFrZG/0+3Zb0e28YG3ZBAQksi7Er145dh3C74GYstqrFV9OCsMXXYRqLyhaILQw3FpAcri6m+ZekUyIAAGBbR5LXzy4BAGCau5POOQV2aONWGQCwDrpqvccvdiEWsAOPtMoRAFZVF9B0nupWC6cAAGBL1yfdgB3YAUPYAKyjbg3VLZTeMdwBAMA2uh3UnbNLAACY5v6ke4sCx8gQNgDr6pnJSUlPBQKOgVXYAKyrHiH5C7NLAADYXudBfiOxGhsAgMl6Ks1ls0sAANjeFcknkxOGOwAA2Mazkw5jXzTcAQDABP+YfDRxtCFMZBU2AOvubcn3JD2ZBgAAttVV2B3Gvnq4AwCACW5MvpqcOtwBR+UkGgA47rjvSH4++UziZBoAALb1+OQLyZ3DHQAATPD6pHMhjwx3AACwjXFPyBaSAAAwyS1JF9OcPNwBW7KIBgC+qcXjLyX3J+/uAwAAOJqeRtOzsS2mAQBgspckFtMAADDZCUm7kNcMdwAAMMGLknYhTx/uAABgG50L+eHksuEOAAAmOC/pUHaHtIENbOMDAFu7Jxk3F7+9DwAAYDvtPt4wuwQAgGmennQ4G5g7fv4KAGzt3uTxSRfWAKGABICjeyA5LTl1uAMAgAnafbxqdglYhQ0A2/t6ckryhORjfQAAANtpF/Lq2SWsNx1IAJimXcgnJt+bfKgPAABgO90X8vr5K6wtHUgAmO7h5CnJGcn7+wAAALbTPSFvSuwLydrSgQSAY/Ol5NuTn0re1QcAALCdE5Nbk5OHOwAAmOD85MrZJQAATPOG5OzZJQAAbK9nZHdBjW19WCsW0QDAzn0+6YKadiHf2wcAALCddh+vS9qNBACASbqx+FWzS1h9hrABYPc+m5ySPC65pw8AAGCKrsq2oAYAgMl6zOFls0tYXYawAWDv9JjDB5MzE0PZrKzj568AwN64N+kwdruRsJIUkACwtx5IHkqODHewghSQALD33pWcldgbEgCAyTqE3b0hTxzuYIVYRAMA+6MLar6RnJ+0IwkrwxA2AOyfNydPTp493AEAwASdB9mzsh8z3AEAwAQXJlfOLgEAYJqrk4tmlwAAsL2uxr4lOWO4AwCACc5Jbk56Ug0sLdv4AMDB+UTyncnPJW/vAwAAmKLzIS+eXQIAwPY6H/L6pEPaAAAwSY86vCFxXjYAAJP1hJorkhaTAAAwyQVJi0hYGlZhA8Dhuiv5tuS5yXv6ABadAhIADt/Hkickz0w+2AewyBSQAHD4vp50j8jHJk9N7klgYSkgAWAxfCX5WvKkpCfV3JfAQlJAAsDi+HzS4vHc5IHkwQQWjgISABZLO48tIruopgts/icBAIBtdY/I18wuAQBgmvOSa5MefQgAAJOcn1yXdFgbAAAmuSjpudmOPAQAYLKLk5uT04Y7AACY4EhyW3LmcAcAABO0iLw16SptAACYpB3IW5Ku0gYAgElaRN6btCMJAACTPCa5MblwuIMD4ihDAFheX0/emTw/OSn5YAL7TgEJAMvtweSO5CeSJyW3J7CvFJAAsPxaRN6XPJR8og8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPbVccf9L7WXZE2z3EVcAAAAAElFTkSuQmCC"
                        }
                    ]
                }
            ]
        }
    }
    console.log('payload_Add_Questionnaires_Attachment', postData);
    try {
        axios({
            method: "POST",
            url: postUrl,
            data: JSON.stringify(postData),
            headers: {
                "Content-Type": "application/json",
            }
        })
            .then(function (response) {
                console.log('Add_Questionnaires_Attachment', response.data);
                const data = response.data.Add_Questionnaires_AttachmentResult.Add_Questionnaires_Attachment_Output;
                console.log('edited_Add_Questionnaires_Attachment', data);


                // dispatch({ type: 'HIDE_LOADER' });

                if (data.statusField == "Success") {
                    dispatch({ type: 'HIDE_LOADER' });
                    dispatch({ type: 'ADD_QUESTIONNAIRES_ATTACHMENT', payload: data.statusField });
                    toast('Success')

                    // NavigationService.navigate('TaskDetails');

                } else {
                    console.log('wrong');
                    return
                }
            })
    } catch (e) {
        //console.log('GET_INSPECTION_DETAILS_ERROR', e.ErrorMsg);
       // dispatch({ type: 'HIDE_LOADER' });
    }

    // dispatch({ type: 'GET_CHECK_LIST', payload: false });
}

export const signOut = () => async (dispatch) => {
    //removeAsync('userToken')
    try {
        await AsyncStorage.removeItem('userToken');
        await AsyncStorage.removeItem('userdetails');
        await AsyncStorage.removeItem('dataAssessmentt');

    } catch (e) {
        // saving error
    }
    dispatch({ type: 'LOGOUT' });
}

export const retrieveToken = () => async (dispatch) => {
    setTimeout(async () => {
        let userToken;
        userToken = null;
        //   userToken=GetAsync('userToken');
        try {
            userToken = await AsyncStorage.getItem('userToken')
        } catch (e) {
            // saving error
        }
        console.log('usertoken_from_retrive',);
        dispatch({ type: 'RETRIEVE_TOKEN', token: userToken });

    }, 1000);

}

export const ShowModal = () => async (dispatch) => {
    console.log('modalpreseed')
    dispatch({ type: 'SHOW_MODAL' });
}


