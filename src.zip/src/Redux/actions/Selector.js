import { useSelector } from 'react-redux';

export const showModal = useSelector(state => state.showModal);
