import CryptoJS from "crypto-js";
import AsyncStorage from '@react-native-async-storage/async-storage';


const convertTob64 = (s) => {
    return CryptoJS.enc.Base64.stringify(CryptoJS.enc.Utf8.parse(s))
};

export function getDateInUtc(serverDate) {
    const now = new Date(serverDate);
    const fullDate = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(),
        now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds());
    //console.log('fulldate', fullDate);

    let full_Date = fullDate.toString().substr(0, fullDate.toString().length - 3);

    //console.log('full date', full_Date);

    return full_Date;

};

export function getCurrentDate() {
    var now = new Date();
    var fullDate = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(),
        now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds());

    // ("00" + (d.getMonth() + 1)).slice(-2) +
    // ("00" + d.getDate()).slice(-2) +
    // d.getFullYear() +  
    // ("00" + d.getHours()).slice(-2) +
    // ("00" + d.getMinutes()).slice(-2) +
    // ("00" + d.getSeconds()).slice(-2)    ;
    fullDate = fullDate.toString().substr(0, fullDate.toString().length - 3);
    //fullDate=fullDate.toString();      

    return fullDate;
};

export const Encrypt = word => {
    let key = CryptoJS.enc.Utf8.parse('8080808080808080');
    let iv = CryptoJS.enc.Utf8.parse('8080808080808080');
    let encryptedlogin = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(word), key,
        {
            iv: iv,
            padding: CryptoJS.pad.Pkcs7,
            mode: CryptoJS.mode.CBC,
            keySize: 128 / 8
        }).toString()
    //console.log('elddddd', encryptedlogin);

    encryptedlogin = convertTob64(encryptedlogin);
    //console.log('el', encryptedlogin);

    return encryptedlogin;

}

export const Decrypt = word => {
    return CryptoJS.AES.decrypt(word, key).toString(CryptoJS.enc.Utf8);
}

export const GetAsync = async (key) => {
    try {
       let getKey = await AsyncStorage.getItem(key);
       return getKey != null ? JSON.parse(jsonValue) : null;
    } catch (e) {
        console.log('errorAsync', e)
    }
}

export const SetAsync = async (key,value) => {
    try {
        let setKey = JSON.stringify(key);
        return setKey = await AsyncStorage.setItem(setKey, value)
    } catch (e) {
        console.log('errorAsync', e)
    }
}

export const removeAsync = async (key) => {
    try {
       await AsyncStorage.removeItem(key)
    } catch (e) {
        // saving error
    }
}