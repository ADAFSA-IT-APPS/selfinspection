import React, { useEffect } from "react";
import { CardStyleInterpolators, createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from "@react-navigation/native";
import Notifications from "../screens/StackScreens/Notifications";
import UserDetails from "../screens/StackScreens/UserDetails";
import HygieneManual from "../screens/StackScreens/HygieneManual";
import RootStackScreen from "./rootStack";
import { useDispatch, useSelector } from 'react-redux';
import { retrieveToken } from "../Redux/actions/SI_Action";
import Tabs from "./tabs";
import Loading from '../Components/Loading'
import { Gesture } from "react-native-gesture-handler";
import { Easing } from "react-native";
import {navigationRef} from './NavigationService'

const Stack = createStackNavigator();

const Stacks = () => {
    const loginState = useSelector(state => state)
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(retrieveToken())
        //console.log('token',loginState.userToken)
    }, []);
/* 
    if (loginState.isLoading) {
        return (
            <Loading />
        )
    }
 */
    const config={
        animation:'spring',
        config:{
            stiffness:1000,
            damping:100,
            mass:3,
            overshootClamping:false,
            restDisplacementThreshold:0.01,
            restSpeedThreshold:0.01,
        }
    }

    const closeConfig={
        animation:'timing',
        config:{
            duration:200,
            easing:Easing.linear
        }
    }

    return (
        /*   <AuthContext.Provider value={authContext}> */
        <NavigationContainer ref={navigationRef}>
            {/*  {loginState.userToken == "true" ? ( */}
            {loginState.userToken ? (
                <Stack.Navigator screenOptions=
                    {{
                        gestureEnabled: true,
                        transitionSpec:{
                            open:config,
                            close:closeConfig
                        }, 
                        cardStyleInterpolator:CardStyleInterpolators.forScaleFromCenterAndroid
                    }}>
                    <Stack.Screen options={{ headerShown: false }} name="Tabs" component={Tabs} />
                    <Stack.Screen options={{ headerShown: false }} name="Notifications" component={Notifications} />
                    <Stack.Screen options={{ headerShown: false }} name="UserDetails" component={UserDetails} />
                    <Stack.Screen options={{ headerShown: false }} name="HygieneManual" component={HygieneManual} />
                </Stack.Navigator>
            ) : <RootStackScreen />
            }
        </NavigationContainer>
        /*   </AuthContext.Provider> */
    );
};

export default Stacks;
