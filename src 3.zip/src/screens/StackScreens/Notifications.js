import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, Image, Dimensions, ScrollView, TouchableOpacity } from "react-native";
import Navbar from "../../Components/Navbar/Navbar";
import SI_ImageCont from "../../Components/SI_ImageCont";
import Loading from "../../Components/Loading";
import NavigationService from '../../navigation/NavigationService';
import { AdhocInspection, Get_Assessment, GetCheckList } from '../../Redux/actions/SI_Action';
import { useDispatch,useSelector } from "react-redux";


const height = Dimensions.get('window').height;
const width = Dimensions.get('window').width;

const Notifications = (props) => {
  const dispatch = useDispatch()
  const [isLoading, setIsLoading] = useState(true);
  const { item } = props.route.params;
  const state = useSelector(state => state);

  useEffect(() => {
    console.log('item', item);
    if (item/* .length>0 */) {
      setIsLoading(false)
    } else {
      setIsLoading(false)

      /*    NavigationService.goBack();
         return */
    }
  }, [item])

  const openTask = (taskId, item) => {
    /*     dispatch(Get_Assessment( taskId => {
            console.log('sssssss', result);
              navigation.navigate('TaskDetails', { taskId: task})
        })); */
    console.log('item', item);
    console.log('taskId', taskId);
    dispatch(Get_Assessment(item, (result) => {
      alertRef.current.show(result.error);
    }));
    dispatch(GetCheckList(item, (result) => {
      alertRef.current.show(result.error);
    }));
  }
  return (
    <View style={styles.container}>
      {/* {isLoading && <Loading />} */}
      {state.isLoading && <Loading />}
      <Navbar nav={'stacksWithoutLogout'} />
      <SI_ImageCont />
      <ScrollView style={{ height: height / 3, width: width / 1.05, marginBottom: height / 7,marginLeft:10 }}>
        {item ?
          item.map((data, index) =>
            <TouchableOpacity onPress={() => openTask(data.inspectionNumberField, data)} style={styles.taskCont}>
              <Text style={styles.textWhite}>New Task Assigned:</Text>
              <Text style={styles.textWhite}>{data.inspectionNumberField}</Text>
            </TouchableOpacity>
          ) :
          <View style={{ alignItems: 'center'/* ,justifyContent:'center' */, flex: 1, }}><Text style={{ color: '#5c6672' }}>No Tasks</Text></View>
        }
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  taskCont: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', backgroundColor: '#5c6672', paddingHorizontal: 10, borderRadius: 5, marginHorizontal: 10, marginVertical: 10, paddingVertical: 15 },
  textWhite: { color: '#fff' }
});
export default Notifications;
