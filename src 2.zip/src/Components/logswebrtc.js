15  ls -lt
16  cd /usr/local/etc
17  ls
18  ls -lt
19  sudo turnserver &
20  which turnserver
21  pwd
22  cd /usr/local/bin
23  ls
24  ls -lt
25  sudo turnserver &
26  sudo ./turnserver &
27  pwd
28  which npm
29  sudo npm start 
30  pwd
31  cd
32  ls
33  cd webrtc_uae\
34  cd webrtc_uae
35  sudo npm start
36  ps -edf | grep -i npm
37  cd webrtc_uae &
38  pwd
39  ls
40  ls -lt
41  sudo npm start
42  sudo npm start &
43  ps -edf | grep -i npm
44  ps -edf | grep -i turnserver
45  code .
46  which code
47  ls -al
48  cd..
49  cd ..
50  ls -al
51  view .bash_history
52  clear
53  ps -edf | grep -i turn
54  ps -edf | grep -i npm
55  ps -edf | grep -i code
56  man code
57  exit
58  pwd
59  clear
60  ls
61  ls -lt
62  ls -al
63  cd .config
64  ls
65  ls -lt
66  pwd
67  cd ..
68  ls
69  ls -lt
70  clear
71  ls -lt
72  view /tmp/ddkhistory.txt 
73  which forever
74  forever start
75  pwd
76  ls
77  cd webrtc_uae
78  ls
79  ps -edf | grep -i forever
80  ls -al
81  sudo forever start app.js
82  cd
83  which forever
84  forver start
85  forvever start
86  forever start
87  pwd
88  cd webrtc_uae
89  ls
90  sudo forever start app.js 
91  sudo forever start 
92  which forever
93  sudo ~/.nvm/versions/node/v10.14.2/bin/forever start app.js
94  ps -edf | grep -i forever
95  view /tmp/ddkhistory.txt 
96  sudo ~/.nvm/versions/node/v10.14.2/bin/forever list
97  sudo ~/.nvm/versions/node/v10.14.2/bin/forever stop 0
98  sudo ~/.nvm/versions/node/v10.14.2/bin/forever stop 
99  sudo ~/.nvm/versions/node/v10.14.2/bin/forever list
100  ps -edf | grep -i forever
101  view /tmp/ddkhistory.txt 
102  exit
103  clear
104  curl www.adremoteinspection.com
105  curl adremoteinspection.com
106  curl adremoteinspection.com:443
107  curl adremoteinspection.com:4443
108  curl adremoteinspection.com:43
109  curl adremoteinspection.com:443
110  curl adremoteinspection.com
111  history | curl
112  history | grep -i curl
113  clear
114  ps -edf | grep -i nsm
115  ps -edf | grep -i nvm
116  ps -edf | grep -i nsm
117  ps -edf | grep -i turnserver
118  ps -edf | grep -i sudo
119  sudo curl adremoteinpsection.com:443
120  curl adremoteinpsection.com:443
121  sudo curl adremoteinpsection.com:443
122  curl adremoteinpsection.com:443
123  curl 217.165.205.3
124  curl 217.165.205.3:443
125  curl 10.226.0.98:443
126  curl 10.226.0.98
127  curl 10.226.0.97
128  clear
129  ls -lt
130  cd webrtc_uae
131  ls
132  ls -lt
133  cd ssl-keys
134  ls
135  ls -lt
136  cd ..
137  view app.js
138  ps -edf | grep -i npm
139  kill -TERM 10275 10276
140  sudo kill -TERM 10275 10276
141  pwd
142  sudo npm start app.js
143  sudo npm start app.js &
144  curl adremoteinspection.com
145  curl adremoteinspection.com:443
146  ps -edf | grep -i npm
147  kill -TERM 11118 11119
148  sudo kill -TERM 11118 11119
149  ps -edf | grep -i turnserver
150  ps -edf | grep -i npm
151  cd webrtc_uae
152  ls
153  ls -lt
154  npmstart app.js &
155  npm start app.js &
156  sudo npm start app.js &
157  curl adremoteinspection.com:443
158  sudo curl adremoteinspection.com:443
159  sudo curl adremoteinspection.com:4443
160  sudo curl adremoteinspection.com:443
161  curl adremoteinspection.com:443
162  node -v
163  code .
164  curl adremoteinspection.com:443
165  view app.js
166  clear
167  ckear
168  clear
169  ps -ed
170  clear
171  ls -lt
172  view app.js
173  clear
174  ps -edf | grep -i npm
175  kill -TERM 11156 11352
176  sudo kill -TERM 11156 11352
177  kill -TERM 11156 11352
178  ps -edf | grep -i npm
179  find ./* -name "app.js" -print

*/
180  cd /Desktop/bkup/working_perfectly/
181  cd ./Desktop/bkup/working_perfectly/
182  ls
183  ls -lt
184  sudo npm start ./app.js &
185  sudo npm start ./app.js 
186  npm start ./app.js 
187  cd
188  ls
189  clear
190  ls -l
191  pwd
192  ls
193  ls -lt
194  cd webrtc_uae
195  ls
196  ls -lt
197  view package-lock.json
198  view app.js
199  clear
200  pwd
201  ps -edf | grep -i turnserver
202  sudo npm start &
203  ps -edf | grep -i npm
204  curl adremoteinspection.com
205  curl adremoteinspection.com:443
206  curl adremoteinspection.com:443/index.html
207  curl adremoteinspection.com:443
208  man curl
209  clear
210  ls
211  sl -lt
212  ls -lt
213  view /tmp/ddkhistory.txt 
214  pwd
215  ls -lt
216  ps -edf | grep -i npm
217  kill -9 11746 11747
218  sudo kill -9 11746 11747
219  ps -edf | grep -i npm
220  pwd
221  npm start &
222  ls -lt
223  which npm
224  chkconfig sshd on
225  sudo su
226  clear
227  curl http://adremoteinspection.com
228  curl https://adremoteinspection.com
229  clear
230  ping adremoteinspection.com
231  nmap --version
232  nmap localhost
233  nmap 217.165.205.3
234  nmap -p 1-65535 localhost
235  nmap -p 1-65535 217.165.205.3
236  man nmap
237  man code
238  which code
239  cd /usr/bin/code
240  cd /usr/bin
241  ls
242  code -?
243  code /h
244  clear
245  cd /usr/local
246  ls
247  cd etc
248  ls
249  ls -lt
250  view turnserver.conf
251  ls -lt
252  pwd
253  which turnserver
254  turnserver
255  clear
256  ls -lt
257  cd ..
258  ls
259  cd bin
260  ls
261  ls -lt
262  clear
263  cd
264  cledar
265  clear
266  ls
267  ls -l
268  cd turnserver-3.2.3.8
269  ls
270  ls -lt
271  cd examples
272  ls
273  ls -lt
274  cd etc
275  ls
276  ls -lt
277  cd ..
278  ls
279  pwd
280  cd scripts
281  ls
282  ls -lt
283  cd ..
284  pwd
285  cd ..
286  sl
287  clear
288  ls -lt
289  cd
290  ls
291  cd
292  clear
293  ls -lt
294  cd webrtc_uae
295  ls
296  sl -lt
297  ls -lt
298  clear
299  pwd
300  cd
301  ls -al
302  ls -alt
303  cd .forever
304  ls
305  ls -al
306  view 0Cr9.log
307  view 9RYH.log
308  pwd
309  cd ..
310  s
311  ls -lt
312  ls -alt 
313  cd webrtc_uae
314  ls
315  ls -alt
316  cd .git
317  ls
318  ls -al
319  cd ..
320  ls -alt
321  ps -edf 
322  ps
323  ps -edf | grep -i turn
324  kill -9 9911
325  ps -edf | grep -i node
326  sudo kill -9 11758
327  clear
328  cd
329  clear
330  cd
331  cd /etc/local/bin
332  cd /usr/local
333  ls
334  cd etc
335  ls
336  ls -lt
337  sudo turnserver &
338  which turnserver
339  sudo su
340  exit
341  clear
342  view /tmp/ddkhistory.txt 
343  pwd
344  ls -lt
345  ls -alt
346  cd Desktop/
347  ls
348  ls -al
349  cd bkup
350  ls
351  ls -al
352  cd working_perfectly
353  ls
354  ls -al
355  view indexOld.html
356  cp index.html index.html.org
357  cp indexOld.html index.html
358  ps -edf | grep -i sudo
359  ps -edf | grep -i npm
360  ps -edf | grep -i sudo
361  kill -9 10179
362  sudo kill -TERM 10179
363  clear
364  ps -edf | grep -i sudo
365  ps -edf | 
366  ps -edf 
367  ps -edf | grep -i au_adfca
368  pwd
369  clear
370  ls -lt
371  ps view index.html.org
372  view index.html.org
373  view index.html
374  clear
375  ls
376  ls -lt
377  view app.js
378  ps -edf | grep -i sudo
379  ps -edf | grep -i turn
380  kill -9 12796
381  ps -def | grep -i npm
382  kill -TERM 12830
383  sudo kill -TERM 12830
384  cd
385  cd webrtc_uae
386  ls
387  ls -lt
388  clear
389  ls -lt
390  pwd
391  su
392  sudo su
393  pwd
394  ls
395  pwd
396  ls
397  clear
398  ls -lt
399  cp index.html index.html.org
400  cp indexOld.html index.html
401  which turnserver
402  sudo /usr/local/bin/turnserver &
403  pwd
404  ls
405  ls -lt
406  sudo npm start app.js &
407  ps -edf | grep -i turnserver
408  pwd
409  ls -lt
410  cp index.html.org index.html
411  view app.js 
412  clear
413  ps -edf | grep -i npm
414  which forever
415  cd /.nvm/versions/node/v10.14.2/bin/forever
416  cd /.nvm/versions/node/v10.14.2/bin
417  cd ~/.nvm/versions/node/v10.14.2/bin
418  ls
419  ls -lt
420  cd npm
421  cd
422  pwd
423  ls
424  ls -lt
425  cd webrtc
426  cd webrtc_uae
427  ls
428  ls -lt
429  ls -al
430  cd ..
431  ls -al
432  cd .yarn
433  ls
434  ls -al
435  cd bin
436  ls
437  ls -al
438  cd ..
439  pwd
440  ls -lt
441  cd CDR_Dashboard
442  ls
443  ls -lt
444  cd CDR
445  ls
446  ls -lt
447  cd nodeq
448  cd node_modules/
449  ls
450  ls -lt
451  pwd
452  cd ..
453  ls
454  ls -lt
455  cd pages
456  ls
457  ls -lt
458  cd
459  exit
460  pwd
461  ls -lt
462  ps -edf | grep -i sudo
463  ls
464  ls -lt
465  cd CDR_Dashboard/
466  ls
467  ls -lt
468  cd CDR
469  ls
470  ls -lt
471  cd public
472  ls
473  ls -lt
474  cd ..
475  dir
476  ls -lt
477  pwd
478  cd ..
479  ls
480  ls -lt
481  cd CDR
482  ls
483  ls -lt
484  sudo npm start &
485  clear
486  ps
487  ps -edf | grep -i npm
488  kill -TERM 22399 22400
489  sudo kill -TERM 22399 22400
490  pwd
491  ls 
492  clear
493  ls
494  ls -lt
495  exit
496  cd CDR_Dashboard/
497  ls
498  ls -lt
499  cd CDR
500  ls
501  ls -lt
502  view next.config.js 
503  view package.json
504  ps -edf | grep -i sudo
505  kill -TERM 12961 12991
506  sudo kill -TERM 12961 12991
507  ps -edf | grep -i npm
508  ps -edf | grep -i turn
509  ps -edf | grep -i turnserver
510  ps -edf | grep -i sudo
511  clear
512  cd
513  cd /etc/local/bin
514  cd /etc/local
515  cd /etc/
516  ls
517  which turnserver
518  cd /usr/local/bin
519  ls
520  ls -lt
521  sudo ./turnserver &
522  ps -edf | grep -i turn
523  cd
524  cd webrtc
525  cd webrtc_uae
526  ls
527  ls -lt
528  sudo npm start &
529  ps -edf | grep -i npm
530  view package.json
531  cd ..
532  ls
533  ls -lt
534  cd CDR_Dashboard/
535  cleart
536  clear
537  ls -lt
538  cd CDR
539  ls
540  ls -lt
541  view package.json 
542  sudo npm start &
543  view package.json
544  view next.config.js
545  file yarn.lock
546  view yarn.lock
547  ls -lt
548  cd pages
549  ls
550  ls -lt
551  cd ..
552  ls
553  ls -lt
554  clear
555  exit
556  cd ./ssl-keys/
557  ls -al
558  cd webrtc_uae
559  ls
560  ls -al
561  cd ./ssl-keys
562  ls -alt
563  cd ..
564  ls
565  l s-lt
566  ls -alt
567  cp app.js app.js.orginal
568  view app.js
569  ps -edf | grep -i npm
570  kill -TERM 22891
571  sudo kill -TERM 22891
572  ps -edf | grep -i npm
573  pwd
574  sudo npm start &
575  view app.js
576  ps -edf | grep -i npm
577  kill -TERM 23443
578  sudo kill -TERM 23443
579  view app.js
580  clear
581  exit
582  clear
583  ls -lt
584  cd webrtc_uae
585  ls
586  ls -l
587  cp app.js.orginal app.js
588  sudo npm start &
589  celar
590  ls -lt
591  ps -edf | grep -i npm
592  exit
593  gedit
594  sudo lsof -i -P -n | grep LISTEN
595  telnet + IP address or hostname + port number
596  telnet 217.165.205.3:443
597  telnet 217.165.205.3 443
598  clear
599  pwd
600  ps -edf | grep -i npm
601  sudo lsof -i -P -n | grep LISTEN
602  suod kill -TERM 23655
603  sudo kill -TERM 23655
604  pwd
605  cd webrtc_uae
606  ls
607  ls -lt
608  view app.js
609  history
610  sudo npm start 
611  sudo npm start  &
612  view app.js
613  vi app.js
614  ps -edf | grep -i sudo
615  sudo lsof -i -P -n | grep LISTEN
616  sudo kill -TERM 30497
617  ps -edf | grep -i npm
618  pwd
619  cd webrtc_uae
620  ls
621  sudo npm start &
622  sudo lsof -i -P -n | grep LISTEN
623  sudo systemctl status firewalld
624  exit
625  sudo systemctl status firewalld
626  clear
627  ip a
628  exit
629  sudo /etc/init. d/dns-clean restart
630  sudo /etc/init d/dns-clean restart
631  sudo /etc/init.d/nscd restart
632  sudo /etc/init.d/dns-clean restart
633  sudo service nscd restart
634  sudo systemd-resolve --flush-caches
635  clear
636  ps -edf | grep -i turn
637  kill -TERM 22841
638  ps -edf | grep -i npm
639  kill -TERM 23030 31453 31460
640  sudo kill -TERM 23030 31453 31460
641  exit
642  clear
643  history | grep -i nameserver
644  nslookup
645  sudo cat /etc/resolv.conf | grep -i nameserver
646  cd
647  clear
648  which turnserver
649  sudo /usr/local/bin/turnserver &
650  cd
651  cd webrtc_uae
652  ls
653  sudo npm start &
654  sudo cat /etc/resolv.conf | grep -i nameserver
655  sudo vi /etc/resolv.conf
656  sudo cp /etc/resolv.conf /etc/resolv.conf.bkp06012022
657  sudo vi /etc/resolv.conf
658  exit
659  sudo vi /etc/resolv.conf
660  ip a
661  clear
662  ls -lt
663  cd CDR_Dashboard/
664  dir
665  ls
666  cd CDR
667  ls
668  sl -lt
669  ls -lt
670  view next.config.js
671  pwd
672  cd ..
673  ls
674  pwd
675  ls
676  ls -lt
677  cd webrtc
678  cd webrtc_uae
679  dir
680  ls
681  ls -lt
682  view app.js
683  exit
684  cd webrtc_uae
685  ls
686  ls -lt
687  vi app.js
688  clear
689  ps -edf | grep -i npm
690  ps -edf | grep -i turn
691  ls -al
692  cd ssl-keys/
693  ls
694  ls -al
695  cd ..
696  cd node_modules/
697  ls
698  ls -al
699  cd .bin
700  ls
701  ls -al
702  cd ..
703  pwd
704  cd ..
705  ls
706  ls -lt
707  view README.md 
708  pwd
709  iptables
710  iptables -h
711  iptables --list
712  iptables -l
713  iptables -L
714  ckear
715  clear
716  sudo iptables -L
717  exit
718  pwd
719  clear
720  ls
721  ls -lt
722  ps -edf | grep -i turn
723  clear
724  pwd
725  ls
726  ls -lt
727  ps -edf | grep -i sudo
728  sudo kill -TERM 4416 4504
729  which turnserver
730  man forever
731  view /tmp/ddkhistory.txt
732  sudo forever start /usr/local/bin/turnserver 
733  which forever
734  sudo ~/.nvm/versions/node/v10.14.2/bin/forever start /usr/local/bin/turnserver 
735  ps -edf | grep -i turnserver
736  sudo ~/.nvm/versions/node/v10.14.2/bin/forever list
737  ps -edf | grep -i turnserver
738  pwd
739  cd webrtc_uae
740  ls
741  ls -lt
742  sudo ~/.nvm/versions/node/v10.14.2/bin/forever start npm start
743  sudo ~/.nvm/versions/node/v10.14.2/bin/forever npm start
744  sudo ~/.nvm/versions/node/v10.14.2/bin/forever list
745  sudo ~/.nvm/versions/node/v10.14.2/bin/forever add npm start
746  sudo ~/.nvm/versions/node/v10.14.2/bin/forever npm start
747  ps -edf | grep -i forever
748  sudo kill -TERM 7487
749  ps -edf | grep -i forever
750  sudo /usr/local/bin/turnserver &
751  pwd
752  sudo npm start &
753  clear
754  cd ..
755  pwd
756  ls
757  ls -lt
758  cd CDR_Dashboard/
759  ls
760  cd CDR
761  ls
762  ls -lt
763  sudo npm start &
764  exit
765  cd CDR_Dashboard/
766  ls
767  cd CDR
768  ps -edf | grep -i NPM
769  exit
770  clear
771  ls -lt
772  cd webrtc
773  cd webrtc_uae
774  ls
775  ls -lt
776  view app.js
777  grep -i room *
778  clear
779  pwd
780  ls
781  cd scripts
782  ls
783  cd script/
784  ls
785  ls -lt
786  view services.js
787  view video-conference.js
788  cd..
789  cd ..
790  ls
791  view index.html
792  clear
793  ls 
794  ls -lt
795  pwd
796  cd ..
797  cd Desktop/
798  ls
799  cd cd bkup
800  ls
801  cd bkup
802  ls
803  ls -lt
804  clear
805  ls -lt
806  pwd
807  cd ..
808  cd Nar/
809  ls
810  cd demo
811  ls
812  ls -lt
813  view index.js
814  which npm
815  sudo npm start index.js
816  sudo npm index.js
817  sudo npm start
818  sudo npm start index.js
819  view /root/.npm/_logs/2022-01-10T07_58_28_609Z-debug.log
820  sudo view /root/.npm/_logs/2022-01-10T07_58_28_609Z-debug.log
821  sudo npm index.js
822  view /tmp/ddkhistory.txt 
823  man npm
824  clear
825  pwd
826  sudo npm 
827  sudo npm repo
828  sudo npm test
829  npm help npm
830  clear
831  ls -lt
832  cd ..
833  ls
834  cd ..
835  ls 
836  ls -lt
837  cd
838  cd webrtc_uae
839  ls
840  ls -lt
841  exit
842  clear
843  ls -lt
844  cd Downloads
845  ls
846  ls -lt
847  cd..
848  ls
849  cd ..
850  ls
851  ls -lt
852  cd turnserver-3.2.3.8
853  ls
854  ls -lt
855  cd examples/
856  ls
857  ls -l
858  cd etc
859  ls
860  ls -lt
861  cd ..
862  ls -lt
863  cd scripts/
864  ls
865  ls -lt
866  view readme.txt 
867  clear
868  ls -lt
869  cd mobile
870  ls
871  ls -lt
872  view mobile_tcp_client.sh
873  clear
874  pwd
875  cd ..
876  exit
877  pwd
878  ls -lt
879  cd webrtc_U
880  cd webrtc_uae
881  ls
882  ls -lt
883  exit
884  pwd
885  clear
886  ls
887  cd webrtc_uae
888  ls
889  ls -lt
890  pwd
891  cd ..
892  ls
893  ls -lt
894  cd webrtc_uae
895  mkdir logs
896  pwd
897  ls -al\
898  ls -alt
899  chmod 777 logs
900  ls -alt
901  ps -edf | grep -i turn*
902  ps -edf | grep -i sudo
903  sudo kill -TERM 7581 7609 7650
904  ps -edf | grep -i sudo
905  pwd
906  sudo /usr/local/bin/turnserver >> ./logs/turnserver.log &
907  cd logs
908  ls
909  ls -al
910  view turnserver.log 
911  cd ...
912  cd ..
913  pwd
914  ls
915  ls -alt
916  pwd
917  sudo npm start >> ./logs/npm.log &
918  pwd
919  cd logs
920  ls
921  ls -al
922  view npm.log
923  pwd
924  cd ..
925  pwd
926  cd CDR_Dashboard/
927  ls
928  cd CDR
929  ls
930  ls -al
931  sudo npm start >> /home/au_adfca/webrtc_uae/logs/CDR.log &
932  cd
933  cd webrtc_uae
934  ls
935  cd logs
936  ls
937  ls -al
938  view CDR.log
939  clear
940  ls -l
941  ls -lt
942  tail -f turnserver.log
943  ls -lt
944  view npm.log
945  ls -lt
946  view npm.log
947  ls -lt
948  view npm.log
949  tail -f npm.log
950  ls -lt
951  tail -f npm.log
952  ls -lt
953  tail -f npm.log
954  exit
955  cd webrtc_uae
956  ls
957  cd logs
958  ls
959  ls -l
960  tail -f npm.log
961  view -rw-rw-r-- 1 au_adfca au_adfca 2433 Jan 12 15:53 npm.log
962  view npm.log
963  exit
964  cd webrtc
965  cd webrtc_uae
966  ls
967  cd logs
968  ls
969  ls -lt
970  view npm.log
971  clear
972  grep -i BODY npm.log 
973  exit
974  grep -i BODY npm.log 
975  view npm.log
976  tail -f npm.log
977  view -rw-rw-r-- 1 au_adfca au_adfca 2433 Jan 12 15:53 npm.log
978  tail -f npm.log
979  cd webrtc
980  grep -i BODY npm.log 
981  ls
982  ls -lt
983  cd webrtc_uae
984  view -rw-rw-r-- 1 au_adfca au_adfca 2433 Jan 12 15:53 npm.log
985  tail -f turnserver.log
986  ls -lt
987  tail -f npm.log
988  view CDR.log
989  exit
990  view CDR.log
991  ls -lt
992  ls
993  cd webrtc_uae
994  ls
995  view npm.log
996  view logs
997  ls -lt
998  cd ..
999  ls -lt
1000  view -rw-rw-r-- 1 au_adfca au_adfca 2433 Jan 12 15:53 npm.log
1001  info
1002  ls -lt
1003  tail -f turnserver.log
1004  cd webrtc_uae
1005  ls -lt
1006  tail -f turnserver.log
1007  view npm.log
1008  view CDR.log
1009  cd..
1010  cd ..
1011  view -rw-rw-r-- 1 au_adfca au_adfca 2433 Jan 12 15:53 npm.log
1012  cd webrtc_uae
1013  view -rw-rw-r-- 1 au_adfca au_adfca 2433 Jan 12 15:53 npm.log
1014  history